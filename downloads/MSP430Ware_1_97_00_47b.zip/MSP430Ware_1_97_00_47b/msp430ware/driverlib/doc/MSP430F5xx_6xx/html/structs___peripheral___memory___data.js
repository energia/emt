var structs___peripheral___memory___data =
[
    [ "memory_1", "structs___peripheral___memory___data.html#a89e339e0e7a7ec922d80136bf1c0abc1", null ],
    [ "memory_2", "structs___peripheral___memory___data.html#a0a6b4f35844052b68bc57d631a8b2d63", null ],
    [ "memory_3", "structs___peripheral___memory___data.html#aa2435b4a584dca8c19b5f421781a3061", null ],
    [ "memory_4", "structs___peripheral___memory___data.html#afa6268acbfe38e817dce3a62fea55087", null ]
];