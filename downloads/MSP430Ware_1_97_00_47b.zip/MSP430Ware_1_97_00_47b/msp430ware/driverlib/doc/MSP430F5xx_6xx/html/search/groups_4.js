var searchData=
[
  ['eusci_5fa_5fspi',['eusci_a_spi',['../group__eusci__a__spi__api.html',1,'']]],
  ['eusci_5fa_5fuart',['eusci_a_uart',['../group__eusci__a__uart__api.html',1,'']]],
  ['eusci_5fb_5fi2c',['eusci_b_i2c',['../group__eusci__b__i2c__api.html',1,'']]],
  ['eusci_5fb_5fspi',['eusci_b_spi',['../group__eusci__b__spi__api.html',1,'']]],
  ['eusci_5fi2c',['eusci_i2c',['../group__eusci__i2c__api.html',1,'']]],
  ['eusci_5fspi',['eusci_spi',['../group__eusci__spi__api.html',1,'']]],
  ['eusci_5fuart',['eusci_uart',['../group__eusci__uart__api.html',1,'']]]
];
