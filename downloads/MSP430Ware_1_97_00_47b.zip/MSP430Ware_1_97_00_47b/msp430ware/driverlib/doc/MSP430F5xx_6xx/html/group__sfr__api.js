var group__sfr__api =
[
    [ "SFR_clearInterrupt", "group__sfr__api.html#ga4649ae1b6c7f6cfbde0b7e37a8818e35", null ],
    [ "SFR_disableInterrupt", "group__sfr__api.html#ga768a39484cfad4105ab43d6293a9ca90", null ],
    [ "SFR_enableInterrupt", "group__sfr__api.html#ga975ae446a2adf3a0cf53b3ad7dc6488f", null ],
    [ "SFR_getInterruptStatus", "group__sfr__api.html#gac742322d8fc99fc78c224874eb480983", null ],
    [ "SFR_setNMIEdge", "group__sfr__api.html#ga5514d7ad75edbafed8abf5584ae4fa98", null ],
    [ "SFR_setResetNMIPinFunction", "group__sfr__api.html#ga1f42456118fb2beb1902b2bc9bac275f", null ],
    [ "SFR_setResetPinPullResistor", "group__sfr__api.html#ga2c33618ac7d717f71e40bbd08b22cbb9", null ]
];