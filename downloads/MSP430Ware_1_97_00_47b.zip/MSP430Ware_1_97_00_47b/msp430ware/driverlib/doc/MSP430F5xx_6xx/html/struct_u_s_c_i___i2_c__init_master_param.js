var struct_u_s_c_i___i2_c__init_master_param =
[
    [ "dataRate", "struct_u_s_c_i___i2_c__init_master_param.html#a6429541810e6f787890171494144a32c", null ],
    [ "i2cClk", "struct_u_s_c_i___i2_c__init_master_param.html#a9eeb476481301fb81756f4495a5a1ca3", null ],
    [ "selectClockSource", "struct_u_s_c_i___i2_c__init_master_param.html#a5855a8f90b4fac7c4da7b6eb5e708f36", null ]
];