var struct_u_s_c_i___s_p_i__init_master_param =
[
    [ "clockPhase", "struct_u_s_c_i___s_p_i__init_master_param.html#abec5884df321ea6d07238aa6376fffc2", null ],
    [ "clockPolarity", "struct_u_s_c_i___s_p_i__init_master_param.html#ae3178f879b5f9f07e462512e7a4cb05e", null ],
    [ "clockSourceFrequency", "struct_u_s_c_i___s_p_i__init_master_param.html#a70ae4f8aa7e2d156caf78713efdb7a9f", null ],
    [ "desiredSpiClock", "struct_u_s_c_i___s_p_i__init_master_param.html#a9a3e86cc8a7d4a6da41b2ff5114e248e", null ],
    [ "msbFirst", "struct_u_s_c_i___s_p_i__init_master_param.html#aa3ac964c7de6e40e364b79fc29607ce5", null ],
    [ "selectClockSource", "struct_u_s_c_i___s_p_i__init_master_param.html#a335d59f0d02acfad70dc97151e4ebca9", null ]
];