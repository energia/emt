var struct_calendar =
[
    [ "DayOfMonth", "struct_calendar.html#ad21be1a4568d4aedc8c09ad059b1a3b6", null ],
    [ "DayOfWeek", "struct_calendar.html#a8a89ddba9ea8401ffbcafe47b5d35f7b", null ],
    [ "Hours", "struct_calendar.html#a752511aa7019e384353afa523f7aa568", null ],
    [ "Minutes", "struct_calendar.html#aea43925b7bb01441db933ef42efe22fc", null ],
    [ "Month", "struct_calendar.html#a658054bb382936c99035117f5502fc50", null ],
    [ "Seconds", "struct_calendar.html#ab2fb7d970d422a527ecb82e43b8522c6", null ],
    [ "Year", "struct_calendar.html#a0a5c9b2b0a7b2531efa953e5fed065df", null ]
];