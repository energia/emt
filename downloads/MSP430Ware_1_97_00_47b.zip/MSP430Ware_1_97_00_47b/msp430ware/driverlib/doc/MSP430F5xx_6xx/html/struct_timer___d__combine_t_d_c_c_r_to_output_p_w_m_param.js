var struct_timer___d__combine_t_d_c_c_r_to_output_p_w_m_param =
[
    [ "clockingMode", "struct_timer___d__combine_t_d_c_c_r_to_output_p_w_m_param.html#a4e1b0036aa5ae0208eccf98b59de9c90", null ],
    [ "clockSource", "struct_timer___d__combine_t_d_c_c_r_to_output_p_w_m_param.html#a92ecf2b73849ccbbdb0ace1a348f8405", null ],
    [ "clockSourceDivider", "struct_timer___d__combine_t_d_c_c_r_to_output_p_w_m_param.html#aaa124b69377eecffa40252a3eac4b774", null ],
    [ "combineCCRRegistersCombination", "struct_timer___d__combine_t_d_c_c_r_to_output_p_w_m_param.html#ae88a5dc95df3cce68a817dc3b65ca68a", null ],
    [ "compareOutputMode", "struct_timer___d__combine_t_d_c_c_r_to_output_p_w_m_param.html#ac3d92e3c65d4284638c301c99f490331", null ],
    [ "dutyCycle1", "struct_timer___d__combine_t_d_c_c_r_to_output_p_w_m_param.html#aa42a93f57551f6ece515c756e870379e", null ],
    [ "dutyCycle2", "struct_timer___d__combine_t_d_c_c_r_to_output_p_w_m_param.html#a010a36bfc7bb2a0ba55588f907448997", null ],
    [ "timerPeriod", "struct_timer___d__combine_t_d_c_c_r_to_output_p_w_m_param.html#a7632704b0a15106e4548ffc9e1f2177e", null ]
];