var struct_e_u_s_c_i___a___s_p_i__change_master_clock_param =
[
    [ "clockSourceFrequency", "struct_e_u_s_c_i___a___s_p_i__change_master_clock_param.html#ae4c42e28fdeac6cb22aee6e249e93656", null ],
    [ "desiredSpiClock", "struct_e_u_s_c_i___a___s_p_i__change_master_clock_param.html#a4ce8fb5c1d8b0c271fb02dc77df065b3", null ]
];