var struct_s_d24___b__initialize_param =
[
    [ "clockDivider", "struct_s_d24___b__initialize_param.html#a4746f7a8c37430761a0d82728f9ce0df", null ],
    [ "clockPreDivider", "struct_s_d24___b__initialize_param.html#ad139a52ae4dbc81c49c934e0de813e58", null ],
    [ "clockSourceSelect", "struct_s_d24___b__initialize_param.html#ae73b0d810909715a33b9378ce2505e6d", null ],
    [ "referenceSelect", "struct_s_d24___b__initialize_param.html#ab438da287ee973a672115c4176371fde", null ]
];