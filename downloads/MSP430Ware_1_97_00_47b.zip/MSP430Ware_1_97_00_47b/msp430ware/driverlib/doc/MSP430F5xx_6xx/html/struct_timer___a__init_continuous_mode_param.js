var struct_timer___a__init_continuous_mode_param =
[
    [ "clockSource", "struct_timer___a__init_continuous_mode_param.html#a88c2ad2d87f4315e9a760763d9f359d3", null ],
    [ "clockSourceDivider", "struct_timer___a__init_continuous_mode_param.html#afc2fe60ad7ad9df117e5de99c475f235", null ],
    [ "startTimer", "struct_timer___a__init_continuous_mode_param.html#ade4267548bcc3730e1d8b3d32ecb7676", null ],
    [ "timerClear", "struct_timer___a__init_continuous_mode_param.html#a6c89b1d8532794ff587c16e7ff1462bf", null ],
    [ "timerInterruptEnable_TAIE", "struct_timer___a__init_continuous_mode_param.html#a056c4509ff52aa8ef202aac11eb441a5", null ]
];