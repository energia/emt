var searchData=
[
  ['sd24_5fb',['sd24_b',['../group__sd24__b__api.html',1,'']]],
  ['sfr',['sfr',['../group__sfr__api.html',1,'']]],
  ['sysctl',['sysctl',['../group__sysctl__api.html',1,'']]]
];
