var struct_e_u_s_c_i___b___i2_c__init_slave_param =
[
    [ "slaveAddress", "struct_e_u_s_c_i___b___i2_c__init_slave_param.html#a5bb4aa0f255239ec6c95956eedc23d20", null ],
    [ "slaveAddressOffset", "struct_e_u_s_c_i___b___i2_c__init_slave_param.html#affbc6e9134e2c403427a3093d6b3fcb9", null ],
    [ "slaveOwnAddressEnable", "struct_e_u_s_c_i___b___i2_c__init_slave_param.html#afd7513311dca8de4ab5d4148d5b5189b", null ]
];