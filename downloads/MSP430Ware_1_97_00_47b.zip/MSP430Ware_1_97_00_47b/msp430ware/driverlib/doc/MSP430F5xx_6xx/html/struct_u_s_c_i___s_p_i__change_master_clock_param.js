var struct_u_s_c_i___s_p_i__change_master_clock_param =
[
    [ "clockSourceFrequency", "struct_u_s_c_i___s_p_i__change_master_clock_param.html#ad21efc9b2829a29bbb8be1f00d711cbf", null ],
    [ "desiredSpiClock", "struct_u_s_c_i___s_p_i__change_master_clock_param.html#a5d3527906457422cfaaac5769bfdd69b", null ]
];