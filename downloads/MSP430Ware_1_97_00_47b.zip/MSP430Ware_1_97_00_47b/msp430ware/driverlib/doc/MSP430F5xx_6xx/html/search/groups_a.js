var searchData=
[
  ['ram',['ram',['../group__ram__api.html',1,'']]],
  ['ref',['ref',['../group__ref__api.html',1,'']]],
  ['rtc_5fa',['rtc_a',['../group__rtc__a__api.html',1,'']]],
  ['rtc_5fb',['rtc_b',['../group__rtc__b__api.html',1,'']]],
  ['rtc_5fc',['rtc_c',['../group__rtc__c__api.html',1,'']]]
];
