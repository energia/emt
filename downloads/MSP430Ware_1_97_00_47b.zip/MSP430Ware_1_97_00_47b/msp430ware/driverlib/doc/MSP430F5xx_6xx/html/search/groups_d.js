var searchData=
[
  ['ucs',['ucs',['../group__ucs__api.html',1,'']]],
  ['usci_5fa_5fspi',['usci_a_spi',['../group__usci__a__spi__api.html',1,'']]],
  ['usci_5fa_5fuart',['usci_a_uart',['../group__usci__a__uart__api.html',1,'']]],
  ['usci_5fb_5fi2c',['usci_b_i2c',['../group__usci__b__i2c__api.html',1,'']]],
  ['usci_5fb_5fspi',['usci_b_spi',['../group__usci__b__spi__api.html',1,'']]],
  ['usci_5fi2c',['usci_i2c',['../group__usci__i2c__api.html',1,'']]],
  ['usci_5fspi',['usci_spi',['../group__usci__spi__api.html',1,'']]],
  ['usci_5fuart',['usci_uart',['../group__usci__uart__api.html',1,'']]]
];
