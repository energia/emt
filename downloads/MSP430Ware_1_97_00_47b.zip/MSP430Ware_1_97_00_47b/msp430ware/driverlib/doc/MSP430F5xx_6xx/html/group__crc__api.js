var group__crc__api =
[
    [ "CRC_getData", "group__crc__api.html#gabfd146dc6616a99e0e7ada62ce4efe1a", null ],
    [ "CRC_getResult", "group__crc__api.html#ga73086d7ba9d2162de6149d965e88a574", null ],
    [ "CRC_getResultBitsReversed", "group__crc__api.html#gac276eb05e9178cdda7ec0b33f99b9987", null ],
    [ "CRC_set16BitData", "group__crc__api.html#ga546982ae7c7bff8b27229b506f3c1dcd", null ],
    [ "CRC_set16BitDataReversed", "group__crc__api.html#ga4527407a07de8d32e77c40fca7eac4f4", null ],
    [ "CRC_set8BitData", "group__crc__api.html#gaabcd07853c69211f509da5a79fdea9c5", null ],
    [ "CRC_set8BitDataReversed", "group__crc__api.html#ga4b84bdb66c91e12c5d9c49b2e26ab66a", null ],
    [ "CRC_setSeed", "group__crc__api.html#gaa7f85d73fc76b7d6fd2e35d548a56e9b", null ]
];