var struct_timer___b__output_p_w_m_param =
[
    [ "clockSource", "struct_timer___b__output_p_w_m_param.html#a6ddcf393d7f37ed782002eb80f823321", null ],
    [ "clockSourceDivider", "struct_timer___b__output_p_w_m_param.html#adcf881b7b18bca1ba2512dc6e283fc0b", null ],
    [ "compareOutputMode", "struct_timer___b__output_p_w_m_param.html#a7b6284b62b93debd38577109255f3121", null ],
    [ "compareRegister", "struct_timer___b__output_p_w_m_param.html#a4949a53a97f06e571895ce6009139085", null ],
    [ "dutyCycle", "struct_timer___b__output_p_w_m_param.html#a1e68c6b230b413ce21f4ef4b2e408693", null ],
    [ "timerPeriod", "struct_timer___b__output_p_w_m_param.html#a614fa666f34e6472ad8b31cb41bcd106", null ]
];