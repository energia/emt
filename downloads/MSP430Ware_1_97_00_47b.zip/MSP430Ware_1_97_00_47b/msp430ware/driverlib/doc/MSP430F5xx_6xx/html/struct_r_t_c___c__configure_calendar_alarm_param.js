var struct_r_t_c___c__configure_calendar_alarm_param =
[
    [ "dayOfMonthAlarm", "struct_r_t_c___c__configure_calendar_alarm_param.html#a8f08f74d559fbae4671354306986c22d", null ],
    [ "dayOfWeekAlarm", "struct_r_t_c___c__configure_calendar_alarm_param.html#a9c58e846386fdd066a2db8530afb8d50", null ],
    [ "hoursAlarm", "struct_r_t_c___c__configure_calendar_alarm_param.html#a139167941d097d00baa7334d738d4105", null ],
    [ "minutesAlarm", "struct_r_t_c___c__configure_calendar_alarm_param.html#a7e50096fded372130d46a782eb7f96bf", null ]
];