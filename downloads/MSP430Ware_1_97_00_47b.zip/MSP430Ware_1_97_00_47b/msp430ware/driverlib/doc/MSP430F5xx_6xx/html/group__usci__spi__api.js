var group__usci__spi__api =
[
    [ "USCI_SPI_changeClockPhasePolarity", "group__usci__spi__api.html#gaf9936c27aeaef6be3a32188bca4607e8", null ],
    [ "USCI_SPI_changeMasterClock", "group__usci__spi__api.html#ga2ef54dc44cd344f3c6165bc990cdaae4", null ],
    [ "USCI_SPI_clearInterruptFlag", "group__usci__spi__api.html#gad2a2183b469898d173aa25ea8fa013f8", null ],
    [ "USCI_SPI_disable", "group__usci__spi__api.html#gac81f43d4e4f574044336ad7c13b433c8", null ],
    [ "USCI_SPI_disableInterrupt", "group__usci__spi__api.html#ga2dbd794e77ff1ebb491912e868d2efc7", null ],
    [ "USCI_SPI_enable", "group__usci__spi__api.html#ga847d655d98a3203f9c55873ba846ce18", null ],
    [ "USCI_SPI_enableInterrupt", "group__usci__spi__api.html#gaaa38135dedae5ca749b37fa1d6d3fb99", null ],
    [ "USCI_SPI_getInterruptStatus", "group__usci__spi__api.html#gae0082c75969269e211df51683e2ea020", null ],
    [ "USCI_SPI_getReceiveBufferAddressForDMA", "group__usci__spi__api.html#gaed39438d16095dd1914e2a255c4cf348", null ],
    [ "USCI_SPI_getTransmitBufferAddressForDMA", "group__usci__spi__api.html#gacc502936508b9dd024775d506ffcb1eb", null ],
    [ "USCI_SPI_initMaster", "group__usci__spi__api.html#ga33d3b62822e4128c72a70d12a31eba06", null ],
    [ "USCI_SPI_isBusy", "group__usci__spi__api.html#ga290d3fbd635733bf2f3104ccc54969cd", null ],
    [ "USCI_SPI_receiveData", "group__usci__spi__api.html#gafaf7c9855f6b6f5d57112168bcfcee50", null ],
    [ "USCI_SPI_slaveInit", "group__usci__spi__api.html#gae3cec696d241a96729325b757a5b0e0f", null ],
    [ "USCI_SPI_transmitData", "group__usci__spi__api.html#ga70180f5bca5eaf10c1b67a372aae7a17", null ]
];