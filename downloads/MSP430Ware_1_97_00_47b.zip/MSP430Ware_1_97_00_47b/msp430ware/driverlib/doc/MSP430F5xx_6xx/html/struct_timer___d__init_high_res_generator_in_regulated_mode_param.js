var struct_timer___d__init_high_res_generator_in_regulated_mode_param =
[
    [ "clockingMode", "struct_timer___d__init_high_res_generator_in_regulated_mode_param.html#aa2678e2243ef97e80180120a148c5a0b", null ],
    [ "clockSource", "struct_timer___d__init_high_res_generator_in_regulated_mode_param.html#a3f53f7d6ccce5f3d8cc413f5826efe7e", null ],
    [ "clockSourceDivider", "struct_timer___d__init_high_res_generator_in_regulated_mode_param.html#a36c75c8db469c65b1e914410ef10fdbb", null ],
    [ "highResClockDivider", "struct_timer___d__init_high_res_generator_in_regulated_mode_param.html#aaea696cf1d3f669ccfb5c99771576c60", null ],
    [ "highResClockMultiplyFactor", "struct_timer___d__init_high_res_generator_in_regulated_mode_param.html#a9c9d93eefc8776c9a8803816693be7cd", null ]
];