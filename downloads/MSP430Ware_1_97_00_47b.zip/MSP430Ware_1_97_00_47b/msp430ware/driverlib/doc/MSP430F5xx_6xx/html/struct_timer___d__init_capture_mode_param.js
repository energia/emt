var struct_timer___d__init_capture_mode_param =
[
    [ "captureInputSelect", "struct_timer___d__init_capture_mode_param.html#a54a8735b91da89c17d770bfc526d53c2", null ],
    [ "captureInterruptEnable", "struct_timer___d__init_capture_mode_param.html#a35e222d310cf90574ffb03207ca472d6", null ],
    [ "captureMode", "struct_timer___d__init_capture_mode_param.html#ab8f361f251017e5ffd08cdcbdb1a7c59", null ],
    [ "captureOutputMode", "struct_timer___d__init_capture_mode_param.html#a2a24060352d10f91449e7ddc0f58bfa0", null ],
    [ "captureRegister", "struct_timer___d__init_capture_mode_param.html#a9af74f351b86e6556cfbf25faf865c08", null ],
    [ "channelCaptureMode", "struct_timer___d__init_capture_mode_param.html#ac63ce61277e774c05cc9e8fa2076b6a8", null ],
    [ "synchronizeCaptureSource", "struct_timer___d__init_capture_mode_param.html#a8fa6603a561226e35579b7aebe8e0cf3", null ]
];