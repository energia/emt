var struct_r_t_c___b__configure_calendar_alarm_param =
[
    [ "dayOfMonthAlarm", "struct_r_t_c___b__configure_calendar_alarm_param.html#a806199b9540a67fb74bc3f476e42316f", null ],
    [ "dayOfWeekAlarm", "struct_r_t_c___b__configure_calendar_alarm_param.html#a0e08a0d02104280cd12c66c86c2808c2", null ],
    [ "hoursAlarm", "struct_r_t_c___b__configure_calendar_alarm_param.html#a68d5a8e44f2c0c56b765439d5547e787", null ],
    [ "minutesAlarm", "struct_r_t_c___b__configure_calendar_alarm_param.html#a04110c41dd1b74febd7d2bfaa41a665f", null ]
];