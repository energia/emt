var struct_e_u_s_c_i___b___s_p_i__init_master_param =
[
    [ "clockPhase", "struct_e_u_s_c_i___b___s_p_i__init_master_param.html#a8d096948e0560eab29962bc15824dfdb", null ],
    [ "clockPolarity", "struct_e_u_s_c_i___b___s_p_i__init_master_param.html#a8b7c3ca6ee8d40262e9bac5a81401c3c", null ],
    [ "clockSourceFrequency", "struct_e_u_s_c_i___b___s_p_i__init_master_param.html#ad0843109c5cb121ab16d88c90ef60565", null ],
    [ "desiredSpiClock", "struct_e_u_s_c_i___b___s_p_i__init_master_param.html#a9c11e6e4c279f88eafc401d732a44306", null ],
    [ "msbFirst", "struct_e_u_s_c_i___b___s_p_i__init_master_param.html#a2c822fbb43fe535a4f95dd137e90288e", null ],
    [ "selectClockSource", "struct_e_u_s_c_i___b___s_p_i__init_master_param.html#ae834477b8f7ccd879b176e135ba64b5c", null ],
    [ "spiMode", "struct_e_u_s_c_i___b___s_p_i__init_master_param.html#a70198b33f80e7e54158933bdd594237b", null ]
];