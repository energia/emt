var group__sysctl__api =
[
    [ "SysCtl_clearJTAGMailboxFlagStatus", "group__sysctl__api.html#ga99b53408b4e23473f1c29c2754d9fe0b", null ],
    [ "SysCtl_disableBSLMemory", "group__sysctl__api.html#ga071c6df09d22e8f69629ffcc72a6ecde", null ],
    [ "SysCtl_disableBSLProtect", "group__sysctl__api.html#ga0f3b56c35f408cbe9b3f1eb43d6f3930", null ],
    [ "SysCtl_disableRAMBasedInterruptVectors", "group__sysctl__api.html#gac630afb702e5fcf9b88739debf70117e", null ],
    [ "SysCtl_enableBSLMemory", "group__sysctl__api.html#ga8d049c3087f5661ff6164f73ccce84ff", null ],
    [ "SysCtl_enableBSLProtect", "group__sysctl__api.html#gaa9e0c379f5bbe392b2d6244bf9a0890e", null ],
    [ "SysCtl_enableDedicatedJTAGPins", "group__sysctl__api.html#ga381147995916e970c8d1d87ea730d98b", null ],
    [ "SysCtl_enablePMMAccessProtect", "group__sysctl__api.html#gaf61145cc7a06ece403c71f04a15f065a", null ],
    [ "SysCtl_enableRAMBasedInterruptVectors", "group__sysctl__api.html#gaceee86d1859e5c5c92b02d402cbe7855", null ],
    [ "SysCtl_getBSLEntryIndication", "group__sysctl__api.html#ga3c0d1bed1463e61abe4c50cb8256e37f", null ],
    [ "SysCtl_getJTAGInboxMessage16Bit", "group__sysctl__api.html#gaa9ea103487441650582b628317bdff3c", null ],
    [ "SysCtl_getJTAGInboxMessage32Bit", "group__sysctl__api.html#ga19a6d4d21501675c65da4400762302a9", null ],
    [ "SysCtl_getJTAGMailboxFlagStatus", "group__sysctl__api.html#ga74c20e76eabf953f22ecdde915c15dc1", null ],
    [ "SysCtl_JTAGMailboxInit", "group__sysctl__api.html#gaaf899b28694f8affd6d3badd5b76799b", null ],
    [ "SysCtl_setBSLSize", "group__sysctl__api.html#ga1ccb15cd62018bf8f39ea05d1f6be1f6", null ],
    [ "SysCtl_setJTAGOutgoingMessage16Bit", "group__sysctl__api.html#gaf9bfd920b7c6a94d13f94642edf1d1c7", null ],
    [ "SysCtl_setJTAGOutgoingMessage32Bit", "group__sysctl__api.html#ga87c96224a61d0fcadb7eb6b052208886", null ],
    [ "SysCtl_setRAMAssignedToBSL", "group__sysctl__api.html#ga4bb4abbb747a223b171b6f9d22066e35", null ]
];