var structuint64 =
[
    [ "RES0", "structuint64.html#a00c03c266a688a0bedbe006e23970ea8", null ],
    [ "RES1", "structuint64.html#adf7fc1ff990ffad115bbfe0af3231b1e", null ],
    [ "RES2", "structuint64.html#a4e2a46f9a9c843fc74ddc727f53b753e", null ],
    [ "RES3", "structuint64.html#a7f77cd6fbf7641e1d501d79be8214a1a", null ]
];