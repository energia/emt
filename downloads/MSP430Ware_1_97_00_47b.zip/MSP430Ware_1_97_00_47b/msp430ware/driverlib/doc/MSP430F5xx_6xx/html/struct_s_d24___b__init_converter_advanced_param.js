var struct_s_d24___b__init_converter_advanced_param =
[
    [ "alignment", "struct_s_d24___b__init_converter_advanced_param.html#a1f0da2bf7784436cd4a5e89f58104abf", null ],
    [ "conversionMode", "struct_s_d24___b__init_converter_advanced_param.html#a9535f2922e00b9378218e85b7da43d64", null ],
    [ "converter", "struct_s_d24___b__init_converter_advanced_param.html#adea3aafb01c0421e7ae0cdfc48ff2094", null ],
    [ "dataFormat", "struct_s_d24___b__init_converter_advanced_param.html#ab2c5fb47dc811d78f6e3e9ce8210d32d", null ],
    [ "gain", "struct_s_d24___b__init_converter_advanced_param.html#a3215bcf86f418ecc4ee16d9fdfe7ec55", null ],
    [ "oversampleRatio", "struct_s_d24___b__init_converter_advanced_param.html#a21e66b30ddd2eaa4915e32dcbeaffba6", null ],
    [ "sampleDelay", "struct_s_d24___b__init_converter_advanced_param.html#a6def0b1b58afb9b7c8b6ea6f4c83d0fd", null ],
    [ "startSelect", "struct_s_d24___b__init_converter_advanced_param.html#a6ebc3eed0f7117a36fffb22337b71b95", null ]
];