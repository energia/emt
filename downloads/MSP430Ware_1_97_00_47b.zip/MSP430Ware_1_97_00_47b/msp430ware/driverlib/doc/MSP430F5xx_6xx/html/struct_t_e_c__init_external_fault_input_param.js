var struct_t_e_c__init_external_fault_input_param =
[
    [ "polarityBit", "struct_t_e_c__init_external_fault_input_param.html#aa7a9c77437de86fad082c90df6bf27de", null ],
    [ "selectedExternalFault", "struct_t_e_c__init_external_fault_input_param.html#a326f5045c43aa97c300bc8e62f65403b", null ],
    [ "signalHold", "struct_t_e_c__init_external_fault_input_param.html#a4aef39510797c92a9a5063460f98322b", null ],
    [ "signalType", "struct_t_e_c__init_external_fault_input_param.html#a2698cb0ba296a2c1c2c87b9ecefdf133", null ]
];