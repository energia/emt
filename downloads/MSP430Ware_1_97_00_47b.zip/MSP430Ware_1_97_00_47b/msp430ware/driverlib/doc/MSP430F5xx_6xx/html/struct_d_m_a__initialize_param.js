var struct_d_m_a__initialize_param =
[
    [ "channelSelect", "struct_d_m_a__initialize_param.html#a9b04b929759df93c0850ac34f6032c03", null ],
    [ "transferModeSelect", "struct_d_m_a__initialize_param.html#a81995e4a588042d2666aa87fa6f39124", null ],
    [ "transferSize", "struct_d_m_a__initialize_param.html#a78fefd2162260e09d6323e74f7447709", null ],
    [ "transferUnitSelect", "struct_d_m_a__initialize_param.html#a06c3b7fd33f2fc8cf0282ef22db2320e", null ],
    [ "triggerSourceSelect", "struct_d_m_a__initialize_param.html#abd6233b5b813ebf7529daa91907ddd3f", null ],
    [ "triggerTypeSelect", "struct_d_m_a__initialize_param.html#a066c0700b1f7c3257898f3225e39dcca", null ]
];