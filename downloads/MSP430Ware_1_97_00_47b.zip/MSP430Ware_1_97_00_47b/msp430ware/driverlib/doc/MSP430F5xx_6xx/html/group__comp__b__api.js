var group__comp__b__api =
[
    [ "Comp_B_clearInterrupt", "group__comp__b__api.html#ga4408e60bdd0ffd695c1c76e5db6deefd", null ],
    [ "Comp_B_configureReferenceVoltage", "group__comp__b__api.html#ga8ca0aad3df10133be4607a9d8747e921", null ],
    [ "Comp_B_disable", "group__comp__b__api.html#ga067f93fde0ce83df03e034a5abbc4b71", null ],
    [ "Comp_B_disableInputBuffer", "group__comp__b__api.html#ga5575dadea9b16eb9822310330a97891f", null ],
    [ "Comp_B_disableInterrupt", "group__comp__b__api.html#ga3dfc7ffad56c9de09be3dd612d1eed93", null ],
    [ "Comp_B_enable", "group__comp__b__api.html#ga85626a5454ac1caa7760a5d210fb1029", null ],
    [ "Comp_B_enableInputBuffer", "group__comp__b__api.html#gae3be217a9498f5e071bb0461f03178c9", null ],
    [ "Comp_B_enableInterrupt", "group__comp__b__api.html#ga71316056b65f88d1b0c808bc03698ebb", null ],
    [ "Comp_B_getInterruptStatus", "group__comp__b__api.html#gaed4b3e8ad6b0ce4c4e1468c9a3c26021", null ],
    [ "Comp_B_initialize", "group__comp__b__api.html#ga7dc6e319ba1ac0a8a57afd409bd67b2c", null ],
    [ "Comp_B_interruptSetEdgeDirection", "group__comp__b__api.html#gaec9b5cd1682c324253a0bdf0fa1b7ff5", null ],
    [ "Comp_B_interruptToggleEdgeDirection", "group__comp__b__api.html#gacf08a8b3d03814f3ff32ca2868efdb7f", null ],
    [ "Comp_B_IOSwap", "group__comp__b__api.html#ga6f191c0d9a760040cc863cb593f4027c", null ],
    [ "Comp_B_outputValue", "group__comp__b__api.html#gae1008c12d75aacc72d1c0279ecca890b", null ],
    [ "Comp_B_shortInputs", "group__comp__b__api.html#ga66aef41761eead7cc88ba2a767b46da0", null ],
    [ "Comp_B_unshortInputs", "group__comp__b__api.html#gada5814ab85959759a775edb192ae45ee", null ]
];