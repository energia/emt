var struct_e_u_s_c_i___i2_c__init_master_param =
[
    [ "autoSTOPGeneration", "struct_e_u_s_c_i___i2_c__init_master_param.html#a02f7c972b163ee2468afee989ab2282d", null ],
    [ "byteCounterThreshold", "struct_e_u_s_c_i___i2_c__init_master_param.html#a35f00929270ff0b429cf0d187cc4caff", null ],
    [ "dataRate", "struct_e_u_s_c_i___i2_c__init_master_param.html#a723b49742ee1ec4ac920f47db906364a", null ],
    [ "i2cClk", "struct_e_u_s_c_i___i2_c__init_master_param.html#a8b73a3648764872b15b5aacfef2fc1c6", null ],
    [ "selectClockSource", "struct_e_u_s_c_i___i2_c__init_master_param.html#ad308003a355cd1a81a2dd3fca2fbc1cd", null ]
];