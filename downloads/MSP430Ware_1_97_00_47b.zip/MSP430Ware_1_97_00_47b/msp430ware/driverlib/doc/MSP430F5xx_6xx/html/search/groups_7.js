var searchData=
[
  ['ldopwr',['ldopwr',['../group__ldopwr__api.html',1,'']]]
];
