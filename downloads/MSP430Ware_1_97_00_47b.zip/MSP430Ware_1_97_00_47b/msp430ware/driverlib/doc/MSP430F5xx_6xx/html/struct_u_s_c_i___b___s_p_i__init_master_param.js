var struct_u_s_c_i___b___s_p_i__init_master_param =
[
    [ "clockPhase", "struct_u_s_c_i___b___s_p_i__init_master_param.html#adaa8fcd96bbb23ace5749a12722a2497", null ],
    [ "clockPolarity", "struct_u_s_c_i___b___s_p_i__init_master_param.html#a1c44c25535b962864250a2a8105723b1", null ],
    [ "clockSourceFrequency", "struct_u_s_c_i___b___s_p_i__init_master_param.html#aa38934544fb8d1da3e9c3ec9172fa718", null ],
    [ "desiredSpiClock", "struct_u_s_c_i___b___s_p_i__init_master_param.html#a66aa392b83cdd5667e62cac3315ef9f8", null ],
    [ "msbFirst", "struct_u_s_c_i___b___s_p_i__init_master_param.html#aed3d111cabbea2b89a2ec04ce997619d", null ],
    [ "selectClockSource", "struct_u_s_c_i___b___s_p_i__init_master_param.html#a6f0f96311650d93b9a73119be86d21e5", null ]
];