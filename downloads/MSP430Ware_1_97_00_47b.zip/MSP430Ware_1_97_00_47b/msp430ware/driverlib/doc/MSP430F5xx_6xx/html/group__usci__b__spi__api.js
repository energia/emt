var group__usci__b__spi__api =
[
    [ "USCI_B_SPI_changeClockPhasePolarity", "group__usci__b__spi__api.html#gabf5977fff4a7fea020789b7df55d2b7c", null ],
    [ "USCI_B_SPI_changeMasterClock", "group__usci__b__spi__api.html#gad610f79ce5150cf53e97f532839a9a93", null ],
    [ "USCI_B_SPI_clearInterruptFlag", "group__usci__b__spi__api.html#ga3ce3c64c4a5314142ec3b7479479eb75", null ],
    [ "USCI_B_SPI_disable", "group__usci__b__spi__api.html#ga48f2e8db90e1c494a4f224a1857edc30", null ],
    [ "USCI_B_SPI_disableInterrupt", "group__usci__b__spi__api.html#ga910e0e053d61c2639acf4e6d56447fc5", null ],
    [ "USCI_B_SPI_enable", "group__usci__b__spi__api.html#gaebf87d9b5f7d01bd9adc770a39acaf67", null ],
    [ "USCI_B_SPI_enableInterrupt", "group__usci__b__spi__api.html#gac4255ced82fa289180ecbfcf5e8627bb", null ],
    [ "USCI_B_SPI_getInterruptStatus", "group__usci__b__spi__api.html#gaefb5ac95e496e7f455a4a3e00402c2e2", null ],
    [ "USCI_B_SPI_getReceiveBufferAddressForDMA", "group__usci__b__spi__api.html#gaf2cad7ef1d925e96876de74f4f4bb227", null ],
    [ "USCI_B_SPI_getTransmitBufferAddressForDMA", "group__usci__b__spi__api.html#gaf71aedac45bc9d35d97f92e552260cc4", null ],
    [ "USCI_B_SPI_initMaster", "group__usci__b__spi__api.html#ga8fc371584c8b2c357f77bae443aa4386", null ],
    [ "USCI_B_SPI_isBusy", "group__usci__b__spi__api.html#ga5c8a12178e7e5bf28a26bf489093d84a", null ],
    [ "USCI_B_SPI_receiveData", "group__usci__b__spi__api.html#ga4711e34f629fb76a247698189ff871a4", null ],
    [ "USCI_B_SPI_slaveInit", "group__usci__b__spi__api.html#ga7c1a1cd42df0d1ca373f5c02583be732", null ],
    [ "USCI_B_SPI_transmitData", "group__usci__b__spi__api.html#gaa55b12fa637455ad92d3f34e3958beb5", null ]
];