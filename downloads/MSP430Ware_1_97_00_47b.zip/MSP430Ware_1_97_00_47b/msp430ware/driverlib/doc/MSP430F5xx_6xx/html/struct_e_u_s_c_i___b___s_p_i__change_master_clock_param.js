var struct_e_u_s_c_i___b___s_p_i__change_master_clock_param =
[
    [ "clockSourceFrequency", "struct_e_u_s_c_i___b___s_p_i__change_master_clock_param.html#ab03a37305dd526f81ca4781599500162", null ],
    [ "desiredSpiClock", "struct_e_u_s_c_i___b___s_p_i__change_master_clock_param.html#ae7f95b3b87ebd2a84d5b9d9e6369a2dc", null ]
];