var group__tec__api =
[
    [ "TEC_clearExternalClearStatus", "group__tec__api.html#gaf2ea59c3b7c4c085d9de6912a6bbafe4", null ],
    [ "TEC_clearExternalFaultStatus", "group__tec__api.html#gad6eca8fde137f05140bd040b6387be59", null ],
    [ "TEC_clearInterruptFlag", "group__tec__api.html#ga38595e38ededcea180b221d505a26b53", null ],
    [ "TEC_disableAuxiliaryClearSignal", "group__tec__api.html#ga52c266bdffcf41167c938dc5bf64191f", null ],
    [ "TEC_disableExternalClearInput", "group__tec__api.html#ga05ad8ca9d6decaa0070eb2410d48154a", null ],
    [ "TEC_disableExternalFaultInput", "group__tec__api.html#ga75e80f8267566f24261234f22198a236", null ],
    [ "TEC_disableInterrupt", "group__tec__api.html#gaaa9c03aac31c1aa4eb268baf7fdb00a1", null ],
    [ "TEC_enableAuxiliaryClearSignal", "group__tec__api.html#ga13d3b876f7b3d6f04dfba9fd192a71ef", null ],
    [ "TEC_enableExternalClearInput", "group__tec__api.html#gafd074b472e81c323def5552d6da4ccdb", null ],
    [ "TEC_enableExternalFaultInput", "group__tec__api.html#ga55118babbc18b3c0ec30a2a24e734ee5", null ],
    [ "TEC_enableInterrupt", "group__tec__api.html#gae302357cf877c98671a0a8a26a235dfd", null ],
    [ "TEC_getExternalClearStatus", "group__tec__api.html#ga36c47eababb45cbad9d9b4360882c939", null ],
    [ "TEC_getExternalFaultStatus", "group__tec__api.html#ga91721437be1e5f947c3d89d2be249b4e", null ],
    [ "TEC_getInterruptStatus", "group__tec__api.html#ga904fe5dec8242aad4ebfdb52cf74946b", null ],
    [ "TEC_initExternalClearInput", "group__tec__api.html#gabf41a134dd334610167597bef70d3ca6", null ],
    [ "TEC_initExternalFaultInput", "group__tec__api.html#ga363ac44b5eaa97cd843fe573d1d42826", null ]
];