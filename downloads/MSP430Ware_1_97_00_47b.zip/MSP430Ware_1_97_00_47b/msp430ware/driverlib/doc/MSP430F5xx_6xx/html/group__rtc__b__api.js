var group__rtc__b__api =
[
    [ "RTC_B_clearInterrupt", "group__rtc__b__api.html#ga8e5a6eee3e5fa21695db032c57ca70a0", null ],
    [ "RTC_B_configureCalendarAlarm", "group__rtc__b__api.html#gad7f8160482527c1bafdacb97dee0056e", null ],
    [ "RTC_B_convertBCDToBinary", "group__rtc__b__api.html#ga173e6ac0cb69f4377065df22099d8fbd", null ],
    [ "RTC_B_convertBinaryToBCD", "group__rtc__b__api.html#gaa9bda479342bf259b682a3773b2e160a", null ],
    [ "RTC_B_definePrescaleEvent", "group__rtc__b__api.html#ga9aad7b446db719424175aa6f6e06479e", null ],
    [ "RTC_B_disableInterrupt", "group__rtc__b__api.html#gae5c6f4ab0c6bb617fca807ed6245f5d1", null ],
    [ "RTC_B_enableInterrupt", "group__rtc__b__api.html#gad7450a5d0d29f03fa04e37b9f13f5cfd", null ],
    [ "RTC_B_getCalendarTime", "group__rtc__b__api.html#gac24f1bd2af4db40e48cce3003cd9c0da", null ],
    [ "RTC_B_getInterruptStatus", "group__rtc__b__api.html#gad0b2bbceb0a3857fa83107dab145086d", null ],
    [ "RTC_B_getPrescaleValue", "group__rtc__b__api.html#gaf1e08a0378002c3bbd4d6d2688e25bc2", null ],
    [ "RTC_B_holdClock", "group__rtc__b__api.html#ga5fddb3c9fc56dc6274b4f45291b71e67", null ],
    [ "RTC_B_initCalendar", "group__rtc__b__api.html#gab2fb733368e87019d8f964e989b94003", null ],
    [ "RTC_B_setCalendarEvent", "group__rtc__b__api.html#ga0800dec4edce3cb1febda4ca02296771", null ],
    [ "RTC_B_setCalibrationData", "group__rtc__b__api.html#ga6c8e36df012cae6e6dd28a2c56f40b3a", null ],
    [ "RTC_B_setCalibrationFrequency", "group__rtc__b__api.html#ga0bd0a28ade68a688d7ae134c1641a26b", null ],
    [ "RTC_B_setPrescaleValue", "group__rtc__b__api.html#gac5fe149840467bbe80039b7baf878a91", null ],
    [ "RTC_B_startClock", "group__rtc__b__api.html#ga12cc97b922358d871596baf91318683e", null ]
];