var structs___t_l_v___a_d_c___cal___data =
[
    [ "adc_gain_factor", "structs___t_l_v___a_d_c___cal___data.html#abef7893af1b0759a62e3ad37500e19a9", null ],
    [ "adc_offset", "structs___t_l_v___a_d_c___cal___data.html#aae1f1da7982d52e73a52b054bff37b86", null ],
    [ "adc_ref15_30_temp", "structs___t_l_v___a_d_c___cal___data.html#a5436393fdd076f121e9fd7c73728391d", null ],
    [ "adc_ref15_85_temp", "structs___t_l_v___a_d_c___cal___data.html#a606169184e24b523cddaa01644af0458", null ],
    [ "adc_ref20_30_temp", "structs___t_l_v___a_d_c___cal___data.html#aec8a1a1ffb7eeb1ca640085d4834f2e1", null ],
    [ "adc_ref20_85_temp", "structs___t_l_v___a_d_c___cal___data.html#afb743578a399d867ecace3b3e0317ffe", null ],
    [ "adc_ref25_30_temp", "structs___t_l_v___a_d_c___cal___data.html#ac1e69e762b6ad80b03b7b7bd93111910", null ],
    [ "adc_ref25_85_temp", "structs___t_l_v___a_d_c___cal___data.html#a3c84a5294032c67c8ae975b4c75500dc", null ]
];