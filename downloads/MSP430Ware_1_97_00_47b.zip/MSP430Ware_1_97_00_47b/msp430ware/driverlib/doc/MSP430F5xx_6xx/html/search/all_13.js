var searchData=
[
  ['year',['Year',['../struct_calendar.html#a0a5c9b2b0a7b2531efa953e5fed065df',1,'Calendar']]]
];
