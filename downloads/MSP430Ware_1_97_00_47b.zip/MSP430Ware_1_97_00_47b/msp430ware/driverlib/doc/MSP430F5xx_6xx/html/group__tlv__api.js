var group__tlv__api =
[
    [ "TLV_getDeviceType", "group__tlv__api.html#gaffe8c199c8591a6ae588254b08cfba00", null ],
    [ "TLV_getInfo", "group__tlv__api.html#gaec263d70207a7ee223de5cb3ce13bffe", null ],
    [ "TLV_getInterrupt", "group__tlv__api.html#gad1b011f0f05f212262e4202b90faf507", null ],
    [ "TLV_getMemory", "group__tlv__api.html#gae92f5e1006b095968b94ec49c2e11095", null ],
    [ "TLV_getPeripheral", "group__tlv__api.html#ga988d7b9ab92c419a04b3e41a2fa52754", null ]
];