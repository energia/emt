var group__usci__uart__api =
[
    [ "USCI_UART_clearInterruptFlag", "group__usci__uart__api.html#ga318a33bc382875c350be997e945a21a5", null ],
    [ "USCI_UART_disable", "group__usci__uart__api.html#ga6ac6de6fbb831a7a56241e8e4bbb9ea9", null ],
    [ "USCI_UART_disableInterrupt", "group__usci__uart__api.html#gad6f7c5530eb54998c519fda8c5d5d52a", null ],
    [ "USCI_UART_enable", "group__usci__uart__api.html#ga251c86caa5180c2fa7f1fafccf17b90d", null ],
    [ "USCI_UART_enableInterrupt", "group__usci__uart__api.html#gac97518c2c76b967b7c679bc0994f565b", null ],
    [ "USCI_UART_getInterruptStatus", "group__usci__uart__api.html#ga7e197e11e691f08f4dce84439f4cfe67", null ],
    [ "USCI_UART_getReceiveBufferAddressForDMA", "group__usci__uart__api.html#ga6e0d44e5e17b2356ff3ea0240feb7823", null ],
    [ "USCI_UART_getTransmitBufferAddressForDMA", "group__usci__uart__api.html#ga60b77c8c857fea2148e9299048d28f3d", null ],
    [ "USCI_UART_init", "group__usci__uart__api.html#ga059d60ecd1d49990d716576fb9fb61ce", null ],
    [ "USCI_UART_queryStatusFlags", "group__usci__uart__api.html#ga3884f2703ee71fb9916fb48a46119e4e", null ],
    [ "USCI_UART_receiveData", "group__usci__uart__api.html#ga1d6c6ccc00900f0e396614b540c6cf12", null ],
    [ "USCI_UART_resetDormant", "group__usci__uart__api.html#ga393142b27fbb33b1cbf3d6479d4cb8c7", null ],
    [ "USCI_UART_setDormant", "group__usci__uart__api.html#gaa264bfe93afe6fd98dc219a970188c2a", null ],
    [ "USCI_UART_transmitAddress", "group__usci__uart__api.html#gafe23b9a9808b60efd04021de85ae139b", null ],
    [ "USCI_UART_transmitBreak", "group__usci__uart__api.html#gaa6c3d6280dc50878405b97bcbab86e14", null ],
    [ "USCI_UART_transmitData", "group__usci__uart__api.html#gabbacf29c3b32073cf7dbc892b87a92d2", null ]
];