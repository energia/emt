var struct_u_s_c_i___a___s_p_i__init_master_param =
[
    [ "clockPhase", "struct_u_s_c_i___a___s_p_i__init_master_param.html#a546de5added1badc89629bda483dc7fb", null ],
    [ "clockPolarity", "struct_u_s_c_i___a___s_p_i__init_master_param.html#a31d327ae3dd379e3ebd218793acbc051", null ],
    [ "clockSourceFrequency", "struct_u_s_c_i___a___s_p_i__init_master_param.html#a1553ec1778a4b9adaebbd9719f670c33", null ],
    [ "desiredSpiClock", "struct_u_s_c_i___a___s_p_i__init_master_param.html#a328220fe6eed0723bb58069c0b2bf0a6", null ],
    [ "msbFirst", "struct_u_s_c_i___a___s_p_i__init_master_param.html#a0eb97bb14e61e778375c34754388021d", null ],
    [ "selectClockSource", "struct_u_s_c_i___a___s_p_i__init_master_param.html#aafdec729da881c610f17dae4fc7e5513", null ]
];