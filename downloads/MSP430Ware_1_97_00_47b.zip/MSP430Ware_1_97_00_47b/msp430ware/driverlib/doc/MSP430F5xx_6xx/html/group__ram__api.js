var group__ram__api =
[
    [ "RAM_getSectorState", "group__ram__api.html#ga6d85db0d4fe97d86b75d0f0736e3e392", null ],
    [ "RAM_setSectorOff", "group__ram__api.html#ga585dddd41f92e71b473bb1e1ad619c9b", null ]
];