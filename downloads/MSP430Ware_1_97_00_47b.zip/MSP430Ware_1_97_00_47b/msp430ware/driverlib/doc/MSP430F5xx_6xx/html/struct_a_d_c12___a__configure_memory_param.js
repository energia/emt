var struct_a_d_c12___a__configure_memory_param =
[
    [ "endOfSequence", "struct_a_d_c12___a__configure_memory_param.html#a0e21b8c9353cd97d07cc4a94fac38f9b", null ],
    [ "inputSourceSelect", "struct_a_d_c12___a__configure_memory_param.html#a37f853c97b716daa9c055c2938928a20", null ],
    [ "memoryBufferControlIndex", "struct_a_d_c12___a__configure_memory_param.html#a42b211ca4c8b3eab780e5730010d3dd1", null ],
    [ "negativeRefVoltageSourceSelect", "struct_a_d_c12___a__configure_memory_param.html#a3966e31fcee5271ca7257189b8d8df82", null ],
    [ "positiveRefVoltageSourceSelect", "struct_a_d_c12___a__configure_memory_param.html#a549f0dfbae12e6973c774913a46880c5", null ]
];