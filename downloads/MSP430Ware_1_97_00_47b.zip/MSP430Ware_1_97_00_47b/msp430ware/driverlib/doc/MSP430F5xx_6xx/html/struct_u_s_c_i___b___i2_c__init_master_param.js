var struct_u_s_c_i___b___i2_c__init_master_param =
[
    [ "dataRate", "struct_u_s_c_i___b___i2_c__init_master_param.html#aabfe9c195ed32903fc5b9d427a78ba38", null ],
    [ "i2cClk", "struct_u_s_c_i___b___i2_c__init_master_param.html#a3c3acf1ab29b79b152e603c0e0638c0d", null ],
    [ "selectClockSource", "struct_u_s_c_i___b___i2_c__init_master_param.html#ae1fc5e8d2cde7807ba6196ac4aaa047d", null ]
];