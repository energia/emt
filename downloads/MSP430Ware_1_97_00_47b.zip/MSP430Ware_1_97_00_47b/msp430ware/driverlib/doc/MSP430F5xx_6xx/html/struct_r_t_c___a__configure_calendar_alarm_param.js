var struct_r_t_c___a__configure_calendar_alarm_param =
[
    [ "dayOfMonthAlarm", "struct_r_t_c___a__configure_calendar_alarm_param.html#a02fb416868e292db62d7a5626c846558", null ],
    [ "dayOfWeekAlarm", "struct_r_t_c___a__configure_calendar_alarm_param.html#a43887b1693b2ceeca6e0831ac256ee58", null ],
    [ "hoursAlarm", "struct_r_t_c___a__configure_calendar_alarm_param.html#aaff691ab4d3eb8a910ec46eec9654d97", null ],
    [ "minutesAlarm", "struct_r_t_c___a__configure_calendar_alarm_param.html#a0c93bb4c3aca4481593c535af208ba57", null ]
];