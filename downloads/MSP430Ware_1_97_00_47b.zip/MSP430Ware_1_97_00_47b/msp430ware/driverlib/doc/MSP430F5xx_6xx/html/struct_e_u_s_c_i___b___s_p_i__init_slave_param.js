var struct_e_u_s_c_i___b___s_p_i__init_slave_param =
[
    [ "clockPhase", "struct_e_u_s_c_i___b___s_p_i__init_slave_param.html#a43efe376168c851d10cebff5924d8605", null ],
    [ "clockPolarity", "struct_e_u_s_c_i___b___s_p_i__init_slave_param.html#acecf46d216111d3f5b54672ddb17502e", null ],
    [ "msbFirst", "struct_e_u_s_c_i___b___s_p_i__init_slave_param.html#a38a0bb4edb0df6c04d309da8d271811d", null ],
    [ "spiMode", "struct_e_u_s_c_i___b___s_p_i__init_slave_param.html#af6c1b902fca40cc55af266cda55ef08f", null ]
];