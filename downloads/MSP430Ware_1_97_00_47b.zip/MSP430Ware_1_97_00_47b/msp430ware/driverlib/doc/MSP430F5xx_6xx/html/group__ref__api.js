var group__ref__api =
[
    [ "Ref_disableReferenceVoltage", "group__ref__api.html#gad62cea47886f3f9e6de11f34405fb33c", null ],
    [ "Ref_disableReferenceVoltageOutput", "group__ref__api.html#ga5f8cdb381a2bff86a8755d030af88fe8", null ],
    [ "Ref_disableTempSensor", "group__ref__api.html#ga88992f570d5ee3199c5b991d199d41a1", null ],
    [ "Ref_enableReferenceVoltage", "group__ref__api.html#ga7b8e7857108fb8025f6494b5640b907f", null ],
    [ "Ref_enableReferenceVoltageOutput", "group__ref__api.html#ga1ec3e0c1d6dc2bc98b6f71c21c6a1456", null ],
    [ "Ref_enableTempSensor", "group__ref__api.html#gaba295f0ac2f01109c9cebcbc7f8bbdac", null ],
    [ "Ref_getBandgapMode", "group__ref__api.html#ga3d5851701c6f7770c0c332fe7eb4c751", null ],
    [ "Ref_isBandgapActive", "group__ref__api.html#gaeff3cf50d08917abc0851e0c26370f20", null ],
    [ "Ref_isRefGenActive", "group__ref__api.html#gab612db816fa7626f55b044f3b6e0f1f4", null ],
    [ "Ref_isRefGenBusy", "group__ref__api.html#ga7056d7666f8d4b74ead843e624e62ea4", null ],
    [ "Ref_setReferenceVoltage", "group__ref__api.html#ga481c5092b5ec4ca322b084f15d1f3a5b", null ]
];