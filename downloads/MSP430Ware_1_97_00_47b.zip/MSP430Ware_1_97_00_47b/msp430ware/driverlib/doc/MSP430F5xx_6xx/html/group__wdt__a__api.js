var group__wdt__a__api =
[
    [ "WDT_A_hold", "group__wdt__a__api.html#ga66c871265f65d4d49e67a31c74438aaa", null ],
    [ "WDT_A_intervalTimerInit", "group__wdt__a__api.html#ga8bbf885e99706779361c67e8122d1110", null ],
    [ "WDT_A_resetTimer", "group__wdt__a__api.html#ga690798edfac35462678f2a6e152e079b", null ],
    [ "WDT_A_start", "group__wdt__a__api.html#gae0a66efec2166b1a6faf45a44ab6f1f6", null ],
    [ "WDT_A_watchdogTimerInit", "group__wdt__a__api.html#ga8bebd2347ada2561cf3d4f98119f8e6a", null ]
];