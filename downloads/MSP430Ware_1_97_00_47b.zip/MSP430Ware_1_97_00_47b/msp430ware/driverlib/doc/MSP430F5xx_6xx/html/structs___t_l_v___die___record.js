var structs___t_l_v___die___record =
[
    [ "die_x_position", "structs___t_l_v___die___record.html#a9cb59d262aae5b033a5c90f6427960ef", null ],
    [ "die_y_position", "structs___t_l_v___die___record.html#aa7489ec57beedac6f124b5bc72352e9d", null ],
    [ "test_results", "structs___t_l_v___die___record.html#a9ac3ac8e4b0f8a5801cc216150f638fe", null ],
    [ "wafer_id", "structs___t_l_v___die___record.html#a3709ae3c649be459f7b3e2a655f34eb7", null ]
];