var struct_e_u_s_c_i___s_p_i__init_slave_param =
[
    [ "clockPhase", "struct_e_u_s_c_i___s_p_i__init_slave_param.html#a4e629c6c5cfde673dc47717ac8238785", null ],
    [ "clockPolarity", "struct_e_u_s_c_i___s_p_i__init_slave_param.html#a6b4d77c5e58f03d6de06592a5039b697", null ],
    [ "msbFirst", "struct_e_u_s_c_i___s_p_i__init_slave_param.html#a6dd3959669650a3e7d6c275d2622febb", null ],
    [ "spiMode", "struct_e_u_s_c_i___s_p_i__init_slave_param.html#a621e1bc0b6a4fa9ea36acf0440c10dfc", null ]
];