var struct_timer___b__init_capture_mode_param =
[
    [ "captureInputSelect", "struct_timer___b__init_capture_mode_param.html#a584ac329f49046f8a53e699d3a96edcd", null ],
    [ "captureInterruptEnable", "struct_timer___b__init_capture_mode_param.html#a918b2bb169c167d360a6dea48aaa3c7f", null ],
    [ "captureMode", "struct_timer___b__init_capture_mode_param.html#a2168c1ebcd76dfea2f70e19752bd111c", null ],
    [ "captureOutputMode", "struct_timer___b__init_capture_mode_param.html#ac135a0a68fca3a348b210878c675ab96", null ],
    [ "captureRegister", "struct_timer___b__init_capture_mode_param.html#a009ca8fb3ae303d46b87a24d3f6e50a9", null ],
    [ "synchronizeCaptureSource", "struct_timer___b__init_capture_mode_param.html#aa0f71c34ca63c9726da18d8704f6ed7e", null ]
];