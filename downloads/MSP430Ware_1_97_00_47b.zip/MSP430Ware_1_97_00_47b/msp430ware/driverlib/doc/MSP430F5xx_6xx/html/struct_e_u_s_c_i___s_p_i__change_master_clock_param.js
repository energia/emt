var struct_e_u_s_c_i___s_p_i__change_master_clock_param =
[
    [ "clockSourceFrequency", "struct_e_u_s_c_i___s_p_i__change_master_clock_param.html#a07614a0f0e51d1d6ecb2e7fc80c9fffb", null ],
    [ "desiredSpiClock", "struct_e_u_s_c_i___s_p_i__change_master_clock_param.html#adc20158b5525f78033bfa129faa2470c", null ]
];