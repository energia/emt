var searchData=
[
  ['pmap_5finitportsparam',['PMAP_initPortsParam',['../struct_p_m_a_p__init_ports_param.html',1,'']]]
];
