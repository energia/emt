var struct_timer___d__init_compare_mode_param =
[
    [ "compareInterruptEnable", "struct_timer___d__init_compare_mode_param.html#a6f3af33570b0ca463cbf420cf7742182", null ],
    [ "compareOutputMode", "struct_timer___d__init_compare_mode_param.html#a5b78141488317e1723661a5108eeebec", null ],
    [ "compareRegister", "struct_timer___d__init_compare_mode_param.html#aa46729a293deed18e2bda56beb828502", null ],
    [ "compareValue", "struct_timer___d__init_compare_mode_param.html#a7c601d4ec07df3fd8ca37de5d782f5f5", null ]
];