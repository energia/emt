var group__battbak__api =
[
    [ "BattBak_chargerInitAndEnable", "group__battbak__api.html#gaa2a4215feb002715cc85e20bbde4977c", null ],
    [ "BattBak_disable", "group__battbak__api.html#ga30fea558bb401fda57b95cbe1275ecf9", null ],
    [ "BattBak_disableBackupSupplyToADC", "group__battbak__api.html#gac04e83b23450683ed29d2a8e45aa4937", null ],
    [ "BattBak_disableCharger", "group__battbak__api.html#gadde8166665decc108f517412095f4a6c", null ],
    [ "BattBak_enableBackupSupplyToADC", "group__battbak__api.html#ga7b3a5020374909d44c74ee66c0ff4783", null ],
    [ "BattBak_getBackupRAMData", "group__battbak__api.html#ga57fb5620e4b5bb75daf7b2ab27e72453", null ],
    [ "BattBak_manuallySwitchToBackupSupply", "group__battbak__api.html#ga10e0082b6492bc03408075e800de3678", null ],
    [ "BattBak_setBackupRAMData", "group__battbak__api.html#ga4314416048dcaf9443368e031c49363b", null ],
    [ "BattBak_unlockBackupSubSystem", "group__battbak__api.html#ga4983c183751246bdee80a9bd84276115", null ]
];