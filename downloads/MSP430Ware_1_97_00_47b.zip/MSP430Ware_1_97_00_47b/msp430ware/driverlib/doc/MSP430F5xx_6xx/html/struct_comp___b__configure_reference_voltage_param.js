var struct_comp___b__configure_reference_voltage_param =
[
    [ "lowerLimitSupplyVoltageFractionOf32", "struct_comp___b__configure_reference_voltage_param.html#aa28afc13fef6828b2c7f8bf3b2c32ada", null ],
    [ "referenceAccuracy", "struct_comp___b__configure_reference_voltage_param.html#a490d4ff890e6f0b6b86f6aeba1fff27a", null ],
    [ "supplyVoltageReferenceBase", "struct_comp___b__configure_reference_voltage_param.html#ab02f42b1bbff13fe041e594f420a8b07", null ],
    [ "upperLimitSupplyVoltageFractionOf32", "struct_comp___b__configure_reference_voltage_param.html#a7a2c2913dd4249e547b93bc59c6a6fa5", null ]
];