var struct_u_s_c_i___b___s_p_i__change_master_clock_param =
[
    [ "clockSourceFrequency", "struct_u_s_c_i___b___s_p_i__change_master_clock_param.html#a24877847fab6d86073a9d3cd713e1a4e", null ],
    [ "desiredSpiClock", "struct_u_s_c_i___b___s_p_i__change_master_clock_param.html#a4989ae634847f87b09faccebc2c36208", null ]
];