var struct_u_s_c_i___a___s_p_i__change_master_clock_param =
[
    [ "clockSourceFrequency", "struct_u_s_c_i___a___s_p_i__change_master_clock_param.html#a9dbd1a33bf1d0c72815de5938a99f799", null ],
    [ "desiredSpiClock", "struct_u_s_c_i___a___s_p_i__change_master_clock_param.html#af20a0504f76142950772057d7b8eb93f", null ]
];