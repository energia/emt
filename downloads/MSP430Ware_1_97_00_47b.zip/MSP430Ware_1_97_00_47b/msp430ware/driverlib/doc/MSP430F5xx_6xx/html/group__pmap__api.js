var group__pmap__api =
[
    [ "PMAP_initPorts", "group__pmap__api.html#ga8502f526d166809e7939f75598f56bff", null ]
];