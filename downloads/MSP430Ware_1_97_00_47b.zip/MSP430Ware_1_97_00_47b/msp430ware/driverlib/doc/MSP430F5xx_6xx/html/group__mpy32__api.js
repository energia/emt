var group__mpy32__api =
[
    [ "MPY32_clearCarryBitValue", "group__mpy32__api.html#ga692f3a81694e17328584b053b8594bdb", null ],
    [ "MPY32_disableFractionalMode", "group__mpy32__api.html#ga83c0235a1029d60d0b2156aa564605ae", null ],
    [ "MPY32_disableSaturationMode", "group__mpy32__api.html#gab3b6ffa3f7f02327260ac318c987768e", null ],
    [ "MPY32_enableFractionalMode", "group__mpy32__api.html#gaa305a12c35535913e6f1eef5cf12b993", null ],
    [ "MPY32_enableSaturationMode", "group__mpy32__api.html#ga1fb1ffe9c28d753ac0303ce353486b3b", null ],
    [ "MPY32_getCarryBitValue", "group__mpy32__api.html#ga17d43977c93fcdc23235e2febca9425e", null ],
    [ "MPY32_getFractionalMode", "group__mpy32__api.html#ga73024d2ce511f91f5a091eee50b1efb6", null ],
    [ "MPY32_getResult", "group__mpy32__api.html#ga00e157318e40a40eb56c3bca91fda200", null ],
    [ "MPY32_getSaturationMode", "group__mpy32__api.html#ga81dad36d1470774fbb2cb1da157d333e", null ],
    [ "MPY32_getSumExtension", "group__mpy32__api.html#gaee3f8bdcf73babd7444f8af1c43a0bb8", null ],
    [ "MPY32_preloadResult", "group__mpy32__api.html#ga5da97fc45c397895c4b521d121e8f69c", null ],
    [ "MPY32_setOperandOne16Bit", "group__mpy32__api.html#gadb373cfefdb32865bff3b52eed143fd8", null ],
    [ "MPY32_setOperandOne24Bit", "group__mpy32__api.html#gadf58d2e09383e4e125dc8b39697a028a", null ],
    [ "MPY32_setOperandOne32Bit", "group__mpy32__api.html#ga44996e5e712ed5dcf8ed60620693bd93", null ],
    [ "MPY32_setOperandOne8Bit", "group__mpy32__api.html#ga4e27d31749381782bac863a604668524", null ],
    [ "MPY32_setOperandTwo16Bit", "group__mpy32__api.html#gac69da60df8cdf6267648842797f6b059", null ],
    [ "MPY32_setOperandTwo24Bit", "group__mpy32__api.html#ga746d031e3164665e33c1bef60347903b", null ],
    [ "MPY32_setOperandTwo32Bit", "group__mpy32__api.html#gab579373502692d9038825f237e3b8957", null ],
    [ "MPY32_setOperandTwo8Bit", "group__mpy32__api.html#gafddd483c1d9df4ba65a2941dd9bfd777", null ],
    [ "MPY32_setWriteDelay", "group__mpy32__api.html#gad70a41a50663e0d4aa941db6b7b9417c", null ]
];