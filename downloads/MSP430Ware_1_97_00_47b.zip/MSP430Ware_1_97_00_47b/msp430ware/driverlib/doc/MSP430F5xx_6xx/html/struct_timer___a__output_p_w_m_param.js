var struct_timer___a__output_p_w_m_param =
[
    [ "clockSource", "struct_timer___a__output_p_w_m_param.html#a26a9a19650a2892e28aef420fdee7202", null ],
    [ "clockSourceDivider", "struct_timer___a__output_p_w_m_param.html#a7f48e85cbddd3aff69c21c17daeba7a0", null ],
    [ "compareOutputMode", "struct_timer___a__output_p_w_m_param.html#a873b12c6a6693f35d959c8c5155ea573", null ],
    [ "compareRegister", "struct_timer___a__output_p_w_m_param.html#af7d16c9c360f2e42338882e1afa99c5f", null ],
    [ "dutyCycle", "struct_timer___a__output_p_w_m_param.html#a1a755cdd5e6e1e25f4f76e8492ea37df", null ],
    [ "timerPeriod", "struct_timer___a__output_p_w_m_param.html#ad6d27d96db7a8b47460a1867bd5f11e8", null ]
];