var group__eusci__spi__api =
[
    [ "EUSCI_SPI_changeClockPhasePolarity", "group__eusci__spi__api.html#gaa085e2ee1ee36ffa826c651f5f5d0c29", null ],
    [ "EUSCI_SPI_changeMasterClock", "group__eusci__spi__api.html#ga09affa89fc469804752c985d0aa6acaf", null ],
    [ "EUSCI_SPI_clearInterruptFlag", "group__eusci__spi__api.html#ga4177f44bfd18cde0450dec1e891dbf91", null ],
    [ "EUSCI_SPI_disable", "group__eusci__spi__api.html#ga058c9d2a776985cfe124c51e03a12e92", null ],
    [ "EUSCI_SPI_disableInterrupt", "group__eusci__spi__api.html#gacb77fd4123e1bebe97a27b7ae4199f67", null ],
    [ "EUSCI_SPI_enable", "group__eusci__spi__api.html#gad43a031df2cadc58eb5fb445ba34ee8a", null ],
    [ "EUSCI_SPI_enableInterrupt", "group__eusci__spi__api.html#gad3ea1bb95b3022c32358e7336071d141", null ],
    [ "EUSCI_SPI_getInterruptStatus", "group__eusci__spi__api.html#ga7424f5469017664195bac1a97667f4af", null ],
    [ "EUSCI_SPI_getReceiveBufferAddress", "group__eusci__spi__api.html#ga7c6e0190c3fb596da8c91774e0c4ca7e", null ],
    [ "EUSCI_SPI_getTransmitBufferAddress", "group__eusci__spi__api.html#gab600b8835e6f5817de2f2ce8af1ac25e", null ],
    [ "EUSCI_SPI_initMaster", "group__eusci__spi__api.html#ga1c5663a4916da86f57952d4a5907e5f4", null ],
    [ "EUSCI_SPI_initSlave", "group__eusci__spi__api.html#ga1222786f5e6db23e9e06077013d59245", null ],
    [ "EUSCI_SPI_isBusy", "group__eusci__spi__api.html#gabd7e28f5a8109a22e93c12c81523372b", null ],
    [ "EUSCI_SPI_receiveData", "group__eusci__spi__api.html#ga159429504c07735f5b788934f785e21b", null ],
    [ "EUSCI_SPI_select4PinFunctionality", "group__eusci__spi__api.html#ga2096c0b7f3951fd37150e9b4bbcc51a5", null ],
    [ "EUSCI_SPI_transmitData", "group__eusci__spi__api.html#gafbc644f3ef91bbd3e436934eb40d0b19", null ]
];