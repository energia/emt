var struct_comp___b__initialize_param =
[
    [ "invertedOutputPolarity", "struct_comp___b__initialize_param.html#a77300486951e1983dc153feba05f6fba", null ],
    [ "negativeTerminalInput", "struct_comp___b__initialize_param.html#af0b5da180931e3bea1c58c2ba4f6ed6c", null ],
    [ "outputFilterEnableAndDelayLevel", "struct_comp___b__initialize_param.html#a57351c80b0ddf9c2945a9c79a63f24a1", null ],
    [ "positiveTerminalInput", "struct_comp___b__initialize_param.html#aa108b26c69951b6a69b7bc8fa2835c50", null ],
    [ "powerModeSelect", "struct_comp___b__initialize_param.html#a9d5de600dd9488568a83e5b35ff9dfed", null ]
];