var struct_e_u_s_c_i___i2_c__init_slave_param =
[
    [ "slaveAddress", "struct_e_u_s_c_i___i2_c__init_slave_param.html#a439cd0b8b08d61df92ff404023b1d04c", null ],
    [ "slaveAddressOffset", "struct_e_u_s_c_i___i2_c__init_slave_param.html#a5fd98d5d995187e21cd54593b269935f", null ],
    [ "slaveOwnAddressEnable", "struct_e_u_s_c_i___i2_c__init_slave_param.html#af4fa35f90840d1b542d04f4997547173", null ]
];