var struct_timer___b__init_compare_mode_param =
[
    [ "compareInterruptEnable", "struct_timer___b__init_compare_mode_param.html#a11b27f4326941c90d0127f83de1c2f3f", null ],
    [ "compareOutputMode", "struct_timer___b__init_compare_mode_param.html#a3868f56960b2e8ebf8e7f28aff19bcef", null ],
    [ "compareRegister", "struct_timer___b__init_compare_mode_param.html#a1a2b21999efc5d5bc5133f935cbdb2e6", null ],
    [ "compareValue", "struct_timer___b__init_compare_mode_param.html#aee1489ca6acc412f776e8e5a3bb213dc", null ]
];