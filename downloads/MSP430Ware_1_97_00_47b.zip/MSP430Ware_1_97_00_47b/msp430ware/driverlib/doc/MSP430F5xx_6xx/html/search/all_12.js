var searchData=
[
  ['wdt_5fa',['wdt_a',['../group__wdt__a__api.html',1,'']]],
  ['wdt_5fa_5fhold',['WDT_A_hold',['../group__wdt__a__api.html#ga66c871265f65d4d49e67a31c74438aaa',1,'WDT_A_hold(uint16_t baseAddress):&#160;wdt_a.c'],['../group__wdt__a__api.html#ga66c871265f65d4d49e67a31c74438aaa',1,'WDT_A_hold(uint16_t baseAddress):&#160;wdt_a.c']]],
  ['wdt_5fa_5fintervaltimerinit',['WDT_A_intervalTimerInit',['../group__wdt__a__api.html#ga8bbf885e99706779361c67e8122d1110',1,'WDT_A_intervalTimerInit(uint16_t baseAddress, uint8_t clockSelect, uint8_t clockDivider):&#160;wdt_a.c'],['../group__wdt__a__api.html#ga8bbf885e99706779361c67e8122d1110',1,'WDT_A_intervalTimerInit(uint16_t baseAddress, uint8_t clockSelect, uint8_t clockDivider):&#160;wdt_a.c']]],
  ['wdt_5fa_5fresettimer',['WDT_A_resetTimer',['../group__wdt__a__api.html#ga690798edfac35462678f2a6e152e079b',1,'WDT_A_resetTimer(uint16_t baseAddress):&#160;wdt_a.c'],['../group__wdt__a__api.html#ga690798edfac35462678f2a6e152e079b',1,'WDT_A_resetTimer(uint16_t baseAddress):&#160;wdt_a.c']]],
  ['wdt_5fa_5fstart',['WDT_A_start',['../group__wdt__a__api.html#gae0a66efec2166b1a6faf45a44ab6f1f6',1,'WDT_A_start(uint16_t baseAddress):&#160;wdt_a.c'],['../group__wdt__a__api.html#gae0a66efec2166b1a6faf45a44ab6f1f6',1,'WDT_A_start(uint16_t baseAddress):&#160;wdt_a.c']]],
  ['wdt_5fa_5fwatchdogtimerinit',['WDT_A_watchdogTimerInit',['../group__wdt__a__api.html#ga8bebd2347ada2561cf3d4f98119f8e6a',1,'WDT_A_watchdogTimerInit(uint16_t baseAddress, uint8_t clockSelect, uint8_t clockDivider):&#160;wdt_a.c'],['../group__wdt__a__api.html#ga8bebd2347ada2561cf3d4f98119f8e6a',1,'WDT_A_watchdogTimerInit(uint16_t baseAddress, uint8_t clockSelect, uint8_t clockDivider):&#160;wdt_a.c']]]
];
