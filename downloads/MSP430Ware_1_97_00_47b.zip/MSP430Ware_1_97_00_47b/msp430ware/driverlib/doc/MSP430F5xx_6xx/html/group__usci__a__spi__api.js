var group__usci__a__spi__api =
[
    [ "USCI_A_SPI_changeClockPhasePolarity", "group__usci__a__spi__api.html#ga0a965cadbb66c4f8a8d81313b36f893b", null ],
    [ "USCI_A_SPI_changeMasterClock", "group__usci__a__spi__api.html#gab4a35b88f53ef081b734957a75c07e68", null ],
    [ "USCI_A_SPI_clearInterruptFlag", "group__usci__a__spi__api.html#ga18192296ba3c0fae7c2fb415f20d9547", null ],
    [ "USCI_A_SPI_disable", "group__usci__a__spi__api.html#ga3114b81ebfa9c5586daa664eb86d1d90", null ],
    [ "USCI_A_SPI_disableInterrupt", "group__usci__a__spi__api.html#ga2902f82d30df02543a1325d22b9e3f99", null ],
    [ "USCI_A_SPI_enable", "group__usci__a__spi__api.html#gad779af60295f47df513121318d766303", null ],
    [ "USCI_A_SPI_enableInterrupt", "group__usci__a__spi__api.html#gaf30076b9769e91ff0ba45c0c18788e1c", null ],
    [ "USCI_A_SPI_getInterruptStatus", "group__usci__a__spi__api.html#ga13eef47645e9b1c222175e040629ea44", null ],
    [ "USCI_A_SPI_getReceiveBufferAddressForDMA", "group__usci__a__spi__api.html#gacfb7c001205e4a67dfc7c99352b43ec5", null ],
    [ "USCI_A_SPI_getTransmitBufferAddressForDMA", "group__usci__a__spi__api.html#ga4857a0b85d0483022f1c097c7fd3a2db", null ],
    [ "USCI_A_SPI_initMaster", "group__usci__a__spi__api.html#gaf1e1718166b250a04d2fbf6a49c4f9ff", null ],
    [ "USCI_A_SPI_isBusy", "group__usci__a__spi__api.html#ga167752b623b433d4862486162d3dea62", null ],
    [ "USCI_A_SPI_receiveData", "group__usci__a__spi__api.html#ga114643811976ff8e5ea37ff673893496", null ],
    [ "USCI_A_SPI_slaveInit", "group__usci__a__spi__api.html#gaa0f5cbde9ffbb9677611a9ddbf5a484b", null ],
    [ "USCI_A_SPI_transmitData", "group__usci__a__spi__api.html#gafdd81b55ecd90f845c935b064ac6648e", null ]
];