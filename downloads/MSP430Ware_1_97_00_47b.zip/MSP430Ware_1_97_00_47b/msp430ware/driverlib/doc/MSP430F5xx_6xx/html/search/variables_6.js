var searchData=
[
  ['gain',['gain',['../struct_s_d24___b__init_converter_advanced_param.html#a3215bcf86f418ecc4ee16d9fdfe7ec55',1,'SD24_B_initConverterAdvancedParam']]]
];
