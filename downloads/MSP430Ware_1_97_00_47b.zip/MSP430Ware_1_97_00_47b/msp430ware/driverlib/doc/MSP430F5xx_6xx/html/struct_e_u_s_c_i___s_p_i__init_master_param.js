var struct_e_u_s_c_i___s_p_i__init_master_param =
[
    [ "clockPhase", "struct_e_u_s_c_i___s_p_i__init_master_param.html#aff1d017df1d1b1fbc6dc85adf508d68a", null ],
    [ "clockPolarity", "struct_e_u_s_c_i___s_p_i__init_master_param.html#a3ba5d466dc23f4827500f49dca8b561c", null ],
    [ "clockSourceFrequency", "struct_e_u_s_c_i___s_p_i__init_master_param.html#a0cf4ad85d27a5f367cb2d13e37d893e3", null ],
    [ "desiredSpiClock", "struct_e_u_s_c_i___s_p_i__init_master_param.html#a8b4ff3c0cf215a5b771931fcf89786c2", null ],
    [ "msbFirst", "struct_e_u_s_c_i___s_p_i__init_master_param.html#ac3622fbf300ae58d5adbad0ca2d3a57b", null ],
    [ "selectClockSource", "struct_e_u_s_c_i___s_p_i__init_master_param.html#a9bd924ecf67a98892910e5e067f9fa3f", null ],
    [ "spiMode", "struct_e_u_s_c_i___s_p_i__init_master_param.html#a156c88bb3c31ea0d276a7222a1f7e9fc", null ]
];