var struct_p_m_a_p__init_ports_param =
[
    [ "numberOfPorts", "struct_p_m_a_p__init_ports_param.html#acfedc22560da61fc49c6f3f95b5870ba", null ],
    [ "portMapping", "struct_p_m_a_p__init_ports_param.html#a177b8d67aaeaeca4b08c3581c1054872", null ],
    [ "portMapReconfigure", "struct_p_m_a_p__init_ports_param.html#a1b083f69a1df30b9f06df01e6c3d1f92", null ],
    [ "PxMAPy", "struct_p_m_a_p__init_ports_param.html#a59310ecfbe9f7ca8c61de54c607b2998", null ]
];