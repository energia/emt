var searchData=
[
  ['negativerefvoltagesourceselect',['negativeRefVoltageSourceSelect',['../struct_a_d_c12___a__configure_memory_param.html#a3966e31fcee5271ca7257189b8d8df82',1,'ADC12_A_configureMemoryParam']]],
  ['negativeterminalinput',['negativeTerminalInput',['../struct_comp___b__initialize_param.html#af0b5da180931e3bea1c58c2ba4f6ed6c',1,'Comp_B_initializeParam']]],
  ['numberofports',['numberOfPorts',['../struct_p_m_a_p__init_ports_param.html#acfedc22560da61fc49c6f3f95b5870ba',1,'PMAP_initPortsParam']]],
  ['numberofstopbits',['numberofStopBits',['../struct_e_u_s_c_i___a___u_a_r_t__init_param.html#a6bd549035e2573a6d6b7d679a155e39e',1,'EUSCI_A_UART_initParam::numberofStopBits()'],['../struct_e_u_s_c_i___u_a_r_t__init_param.html#a95b178929b5a5027735edb7a0ee6ea8c',1,'EUSCI_UART_initParam::numberofStopBits()'],['../struct_u_s_c_i___a___u_a_r_t__init_param.html#ad9973781a01b291d226fed4014cfdc53',1,'USCI_A_UART_initParam::numberofStopBits()'],['../struct_u_s_c_i___u_a_r_t__init_param.html#a71d069fde4fe5d0f349fe15110ec7e98',1,'USCI_UART_initParam::numberofStopBits()']]]
];
