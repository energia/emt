//*****************************************************************************
//
// Copyright (C) 2013 - 2014 Texas Instruments Incorporated - http://www.ti.com/
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//  Redistributions of source code must retain the above copyright
//  notice, this list of conditions and the following disclaimer.
//
//  Redistributions in binary form must reproduce the above copyright
//  notice, this list of conditions and the following disclaimer in the
//  documentation and/or other materials provided with the
//  distribution.
//
//  Neither the name of Texas Instruments Incorporated nor the names of
//  its contributors may be used to endorse or promote products derived
//  from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// MSP430 intrinsic redefinitions for use with MSP432 Family Devices
//
//****************************************************************************

//*****************************************************************************
// CMSIS-compatible Interrupt Number Definition
//*****************************************************************************
#ifndef __CMSIS_CONFIG__
#define __CMSIS_CONFIG__

typedef enum IRQn
{
  // Cortex-M4 Processor Exceptions Numbers
  NonMaskableInt_IRQn         = -14,    /*  2 Non Maskable Interrupt */
  HardFault_IRQn              = -13,    /*  3 Hard Fault Interrupt */
  MemoryManagement_IRQn       = -12,    /*  4 Memory Management Interrupt */
  BusFault_IRQn               = -11,    /*  5 Bus Fault Interrupt */
  UsageFault_IRQn             = -10,    /*  6 Usage Fault Interrupt */
  SVCall_IRQn                 = -5,     /* 11 SV Call Interrupt */
  DebugMonitor_IRQn           = -4,     /* 12 Debug Monitor Interrupt */
  PendSV_IRQn                 = -2,     /* 14 Pend SV Interrupt */
  SysTick_IRQn                = -1,     /* 15 System Tick Interrupt */
  //  Peripheral Exceptions Numbers
  PSS_IRQn                    =  0,     /* 16 PSS Interrupt */
  CS_IRQn                     =  1,     /* 17 CS Interrupt */
  PCM_IRQn                    =  2,     /* 18 PCM Interrupt */
  WDT_IRQn                    =  3,     /* 19 WDT Interrupt */
  FPU_IRQn                    =  4,     /* 20 FPU Interrupt */
  FLCTL_IRQn                  =  5,     /* 21 FLCTL Interrupt */
  COMP0_IRQn                  =  6,     /* 22 COMP0 Interrupt */
  COMP1_IRQn                  =  7,     /* 23 COMP1 Interrupt */
  TA0_0_IRQn                  =  8,     /* 24 TA0_0 Interrupt */
  TA0_N_IRQn                  =  9,     /* 25 TA0_N Interrupt */
  TA1_0_IRQn                  = 10,     /* 26 TA1_0 Interrupt */
  TA1_N_IRQn                  = 11,     /* 27 TA1_N Interrupt */
  TA2_0_IRQn                  = 12,     /* 28 TA2_0 Interrupt */
  TA2_N_IRQn                  = 13,     /* 29 TA2_N Interrupt */
  TA3_0_IRQn                  = 14,     /* 30 TA3_0 Interrupt */
  TA3_N_IRQn                  = 15,     /* 31 TA3_N Interrupt */
  EUSCIA0_IRQn                = 16,     /* 32 EUSCIA0 Interrupt */
  EUSCIA1_IRQn                = 17,     /* 33 EUSCIA1 Interrupt */
  EUSCIA2_IRQn                = 18,     /* 34 EUSCIA2 Interrupt */
  EUSCIA3_IRQn                = 19,     /* 35 EUSCIA3 Interrupt */
  EUSCIB0_IRQn                = 20,     /* 36 EUSCIB0 Interrupt */
  EUSCIB1_IRQn                = 21,     /* 37 EUSCIB1 Interrupt */
  EUSCIB2_IRQn                = 22,     /* 38 EUSCIB2 Interrupt */
  EUSCIB3_IRQn                = 23,     /* 39 EUSCIB3 Interrupt */
  ADC14_IRQn                  = 24,     /* 40 ADC12 Interrupt */
  T32_INT1_IRQn               = 25,     /* 41 T32_INT1 Interrupt */
  T32_INT2_IRQn               = 26,     /* 42 T32_INT2 Interrupt */
  T32_INTC_IRQn               = 27,     /* 43 T32_INTC Interrupt */
  AES_IRQn                    = 28,     /* 44 AES Interrupt */
  RTCC_IRQn                   = 29,     /* 45 RTCC Interrupt */
  DMA_ERR_IRQn                = 30,     /* 46 DMA_ERR Interrupt */
  DMA_INT3_IRQn               = 31,     /* 47 DMA_INT3 Interrupt */
  DMA_INT2_IRQn               = 32,     /* 48 DMA_INT2 Interrupt */
  DMA_INT1_IRQn               = 33,     /* 49 DMA_INT1 Interrupt */
  DMA_INT0_IRQn               = 34,     /* 50 DMA_INT0 Interrupt */
  PORT1_IRQn                  = 35,     /* 51 PORT1 Interrupt */
  PORT2_IRQn                  = 36,     /* 52 PORT2 Interrupt */
  PORT3_IRQn                  = 37,     /* 53 PORT3 Interrupt */
  PORT4_IRQn                  = 38,     /* 54 PORT4 Interrupt */
  PORT5_IRQn                  = 39,     /* 55 PORT5 Interrupt */
  PORT6_IRQn                  = 40      /* 56 PORT6 Interrupt */
} IRQn_Type;


//*****************************************************************************
// CMSIS-compatible configuration of the Cortex-M4 Processor and Core Peripherals
//*****************************************************************************
#define __MPU_PRESENT           1     // MPU present or not
#define __NVIC_PRIO_BITS        3     // Number of Bits used for Prio Levels
#define __FPU_PRESENT           1     // FPU present or not

#endif // __CMSIS_CONFIG__

// Intrinsics with ARM equivalents
#if defined ( __TMS470__ ) /* TI CGT Compiler */

#include <cmsis_ccs.h>

// These intrinsics need to be added to CGT
#define __get_MSP()                     0
#define __set_MSP(x)                    {}
#define __get_PRIMASK()                 0
#define __set_PRIMASK(x)                {}

#define __sleep()                       __wfi()
#define __deep_sleep()                  { (*((volatile uint32_t *)(0xE000ED10))) |= 0x00000004; __wfi(); (*((volatile uint32_t *)(0xE000ED10))) &= ~0x00000004; }
#define __low_power_mode_off_on_exit()  { (*((volatile uint32_t *)(0xE000ED10))) &= ~0x00000002; }
#define __get_SP_register()             __get_MSP()
#define __set_SP_register(x)            __set_MSP(x)
#define __get_interrupt_state()         __get_PRIMASK()
#define __set_interrupt_state(x)        __set_PRIMASK(x)
#define __enable_interrupt()            _enable_interrupts()
#define __enable_interrupts()           _enable_interrupts()
#define __disable_interrupt()           _disable_interrupts()
#define __disable_interrupts()          _disable_interrupts()
#define __no_operation()                __asm("  nop")

#elif defined ( __ICCARM__ )  /* IAR Compiler */

#include <stdint.h>

#define __INLINE                        inline
#include <cmsis_iar.h>

#define __sleep()                       __WFI()
#define __deep_sleep()                  { (*((volatile uint32_t *)(0xE000ED10))) |= 0x00000004; __WFI(); (*((volatile uint32_t *)(0xE000ED10))) &= ~0x00000004; }
#define __low_power_mode_off_on_exit()  { (*((volatile uint32_t *)(0xE000ED10))) &= ~0x00000002; }
#define __get_SP_register()             __get_MSP()
#define __set_SP_register()             __set_MSP()
#define __get_interrupt_state()         __get_PRIMASK()
#define __set_interrupt_state(x)        __set_PRIMASK(x)
#define __enable_interrupt()            __asm("  cpsie i")
#define __enable_interrupts()           __asm("  cpsie i")
#define __disable_interrupt()           __asm("  cpsid i")
#define __disable_interrupts()          __asm("  cpsid i")
#define __no_operation()                __no_operation()

#elif defined ( __CC_ARM ) /* ARM Compiler */

#define __sleep()                       __wfi
#define __deep_sleep()                  { (*((volatile uint32_t *)(0xE000ED10))) |= 0x00000004; __wfi(); (*((volatile uint32_t *)(0xE000ED10))) &= ~0x00000004; }
#define __low_power_mode_off_on_exit()  { (*((volatile uint32_t *)(0xE000ED10))) &= ~0x00000002; }
#define __get_SP_register()             __get_MSP()
#define __set_SP_register(x)            __set_MSP(x)
#define __get_interrupt_state()         __get_PRIMASK()
#define __set_interrupt_state(x)        __set_PRIMASK(x)
#define __enable_interrupt()            __asm("  cpsie i")
#define __enable_interrupts()           __asm("  cpsie i")
#define __disable_interrupt()           __asm("  cpsid i")
#define __disable_interrupts()          __asm("  cpsid i")
#define __no_operation()                __no_operation()

#elif defined ( __GNUC__ ) /* GCC Compiler */

#define __sleep()                       __wfi()
#define __deep_sleep()                  { (*((volatile uint32_t *)(0xE000ED10))) |= 0x00000004; __wfi(); (*((volatile uint32_t *)(0xE000ED10))) &= ~0x00000004; }
#define __low_power_mode_off_on_exit()  { (*((volatile uint32_t *)(0xE000ED10))) &= ~0x00000002; }
#define __get_SP_register()             __get_MSP()
#define __set_SP_register(x)            __set_MSP(x)
#define __get_interrupt_state()         __get_PRIMASK()
#define __set_interrupt_state(x)        __set_PRIMASK(x)
#define __enable_interrupt()            __asm("  cpsie i")
#define __enable_interrupts()           __asm("  cpsie i")
#define __disable_interrupt()           __asm("  cpsid i")
#define __disable_interrupts()          __asm("  cpsid i")
#define __no_operation()                __no_operation()

#endif


// Intrinsics without ARM equivalents
#define __low_power_mode_0()            { __sleep(); }
#define __low_power_mode_1()            { __sleep(); }
#define __low_power_mode_2()            { __sleep(); }
#define __low_power_mode_3()            { __deep_sleep(); }
#define __low_power_mode_4()            { __deep_sleep(); }
#define __bcd_add_short(x,y)            { while(1); /* Using not-supported MSP430 intrinsic. No replacement available. */ }
#define __bcd_add_long(x,y)             { while(1); /* Using not-supported MSP430 intrinsic. No replacement available. */ }
#define __bcd_add_long_long(x,y)        { while(1); /* Using not-supported MSP430 intrinsic. No replacement available. */ }
#define __even_in_range(x,y)            { while(1); /* Using not-supported MSP430 intrinsic. No replacement available. */ }
#define __swap_bytes(x)                 { while(1); /* Using not-supported MSP430 intrinsic. No replacement available. */ }
#define __data16_read_addr(x)           (*((volatile uint32_t *)(x)))
#define __data20_read_char(x)           (*((volatile uint8_t *)(x)))
#define __data20_read_short(x)          (*((volatile uint16_t *)(x)))
#define __data20_read_long(x)           (*((volatile uint32_t *)(x)))
#define __data16_write_addr(x,y)        { (*((volatile uint32_t *)(x))) }
#define __data20_write_char(x,y)        { while(1); /* Using not-supported MSP430 intrinsic. No replacement available. */ }
#define __data20_write_short(x,y)       { while(1); /* Using not-supported MSP430 intrinsic. No replacement available. */ }
#define __data20_write_long(x,y)        { while(1); /* Using not-supported MSP430 intrinsic. No replacement available. */ }
#define __never_executed()              { while(1); /* Using not-supported MSP430 intrinsic. No replacement available. */ }
#define __op_code()                     { while(1); /* Using not-supported MSP430 intrinsic. No replacement available. */ }
#define __code_distance()               { while(1); /* Using not-supported MSP430 intrinsic. No replacement available. */ }
#define __get_SR_register()             0
#define __bic_SR_register(x)            { while(1); /* Using not-supported MSP430 intrinsic. No replacement available. */ }
#define __bis_SR_register(x)            { while(1); /* Using not-supported MSP430 intrinsic. No replacement available. */ }
#define __get_SR_register_on_exit()     0
#define __bis_SR_register_on_exit(x)    { while(1); /* Using not-supported MSP430 intrinsic. Recommended to write to SCS_SCR register. */ }
#define __bic_SR_register_on_exit(x)    { while(1); /* Using not-supported MSP430 intrinsic. Recommended to write to SCS_SCR register. */ }
