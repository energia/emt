/*
 * -------------------------------------------
 *    MSP432 DriverLib - v01_03_00_18 
 * -------------------------------------------
 *
 * --COPYRIGHT--,BSD,BSD
 * Copyright (c) 2014, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
/* Standard Includes */
#include <stdint.h>
#include "register_remap.h"

/* DriverLib Includes */
#include <cs.h>
#include <debug.h>
#include <sysctl.h>
#include <interrupt.h>

/* Statics */
static uint32_t hfxtFreq;
static uint32_t lfxtFreq;

#ifdef DEBUG

bool __CSIsClockDividerValid(uint8_t divider)
{
    return ((divider == CS_CLOCK_DIVIDER_1) || (divider == CS_CLOCK_DIVIDER_2)
            || (divider == CS_CLOCK_DIVIDER_4) || (divider == CS_CLOCK_DIVIDER_8)
            || (divider == CS_CLOCK_DIVIDER_16) || (divider == CS_CLOCK_DIVIDER_32)
            || (divider == CS_CLOCK_DIVIDER_64) || (divider == CS_CLOCK_DIVIDER_128));
}

#endif

static uint32_t __CSGetHFXTFrequency()
{
    if (hfxtFreq >= CS_1MHZ && hfxtFreq <= CS_4MHZ)
        return CS_CTL2_HFXTFREQ__0;
    else if (hfxtFreq > CS_4MHZ && hfxtFreq <= CS_8MHZ)
        return CS_CTL2_HFXTFREQ__1;
    else if (hfxtFreq > CS_8MHZ && hfxtFreq <= CS_16MHZ)
        return CS_CTL2_HFXTFREQ__2;
    else if (hfxtFreq > CS_16MHZ && hfxtFreq <= CS_24MHZ)
        return CS_CTL2_HFXTFREQ__3;
    else if (hfxtFreq > CS_24MHZ && hfxtFreq <= CS_32MHZ)
        return CS_CTL2_HFXTFREQ__4;
    else if (hfxtFreq > CS_32MHZ && hfxtFreq <= CS_40MHZ)
        return CS_CTL2_HFXTFREQ__5;
    else if (hfxtFreq > CS_40MHZ && hfxtFreq <= CS_48MHZ)
        return CS_CTL2_HFXTFREQ__5;
    else
    {
        ASSERT(false);
        return 0;
    }

}

static uint32_t __CSGetDividerValue(uint32_t wDivider)
{
    switch (wDivider)
    {
    case CS_CLOCK_DIVIDER_1:
        return 1;
    case CS_CLOCK_DIVIDER_2:
        return 2;
    case CS_CLOCK_DIVIDER_4:
        return 4;
    case CS_CLOCK_DIVIDER_8:
        return 8;
    case CS_CLOCK_DIVIDER_16:
        return 16;
    case CS_CLOCK_DIVIDER_32:
        return 32;
    case CS_CLOCK_DIVIDER_64:
        return 64;
    case CS_CLOCK_DIVIDER_128:
        return 128;
    default:
        ASSERT(false);
        return 1;
    }
}

static uint32_t __CSComputeCLKFrequency(uint32_t wClockSource,
        uint32_t wDivider)
{
    uint8_t bDivider;

    bDivider = __CSGetDividerValue(wDivider);

    switch (wClockSource)
    {
    case CS_LFXTCLK_SELECT:
    {
        if (BITBAND_PERI(CS->rIFG.r, LFXTIFG_OFS))
        {
            CS_clearInterruptFlag(CS_IFG_LFXTIFG);

            if (BITBAND_PERI(CS->rIFG.r, LFXTIFG_OFS))
            {
                if (BITBAND_PERI(CS->rCLKEN.r, REFOFSEL_OFS))
                    return (128000 / bDivider);
                else
                    return (32000 / bDivider);
            }
        }
        return lfxtFreq / bDivider;
    }
    case CS_HFXTCLK_SELECT:
    {
        if (BITBAND_PERI(CS->rIFG.r, HFXTIFG_OFS))
        {
            CS_clearInterruptFlag(CS_IFG_HFXTIFG);

            if (BITBAND_PERI(CS->rIFG.r, HFXTIFG_OFS))
            {
                if (BITBAND_PERI(CS->rCLKEN.r, REFOFSEL_OFS))
                    return (128000 / bDivider);
                else
                    return (32000 / bDivider);
            }
        }
        return hfxtFreq / bDivider;
    }
    case CS_VLOCLK_SELECT:
        return CS_VLOCLK_FREQUENCY / bDivider;
    case CS_REFOCLK_SELECT:
    {
        if (BITBAND_PERI(CS->rCLKEN.r, REFOFSEL_OFS))
            return (128000 / bDivider);
        else
            return (32000 / bDivider);
    }
    case CS_DCOCLK_SELECT:
        return (CS_getDCOFrequency() / bDivider);
    case CS_MODOSC_SELECT:
        return CS_MODCLK_FREQUENCY / bDivider;
    default:
        ASSERT(false);
        return 0;
    }
}

//******************************************************************************
// Internal function for getting DCO nominal frequency
//******************************************************************************
static uint32_t __CSGetDOCFrequency(void)
{
    uint32_t dcoFreq;

    switch (CS->rCTL0.r & CS_CTL0_DCORSEL__M)
    {
    case CS_CTL0_DCORSEL__0:
        dcoFreq = 1500000;
        break;
    case CS_CTL0_DCORSEL__1:
        dcoFreq = 3000000;
        break;
    case CS_CTL0_DCORSEL__2:
        dcoFreq = 6000000;
        break;
    case CS_CTL0_DCORSEL__3:
        dcoFreq = 12000000;
        break;
    case CS_CTL0_DCORSEL__4:
        dcoFreq = 24000000;
        break;
    case CS_CTL0_DCORSEL__5:
        dcoFreq = 48000000;
        break;
    default:
        dcoFreq = 0;
    }

    return (dcoFreq);
}

void CS_setExternalClockSourceFrequency(uint32_t lfxt_XT_CLK_frequency,
        uint32_t hfxt_XT_CLK_frequency)
{
    hfxtFreq = hfxt_XT_CLK_frequency;
    lfxtFreq = lfxt_XT_CLK_frequency;
}

void CS_initClockSignal(uint32_t selectedClockSignal, uint32_t clockSource,
        uint32_t clockSourceDivider)
{
    ASSERT(__CSIsClockDividerValid(clockSourceDivider));

    /* Unlocking the CS Module */
    CS->rACC.r = CS_KEY;

    switch (selectedClockSignal)
    {
    case CS_ACLK:
    {
        /* Making sure that the clock signal for ACLK isn't set to anything
         * invalid
         */
        ASSERT(
                (selectedClockSignal != CS_DCOCLK_SELECT)
                && (selectedClockSignal != CS_MODOSC_SELECT)
                && (selectedClockSignal != CS_HFXTCLK_SELECT));

        /* Waiting for the clock source ready bit to be valid before
         * changing */
        while (!BITBAND_PERI(CS->rSTAT.r, ACLK_READY_OFS))
            ;

        /* Setting the divider and source */
        CS->rCTL1.r = ((clockSourceDivider >> CS_ACLK_DIV_BITPOS)
                | (clockSource << CS_ACLK_SRC_BITPOS))
                | (CS->rCTL1.r & ~(CS_CTL1_SELA__M | CS_CTL1_DIVA__M));

        /* Waiting for ACLK to be ready again */
        while (!BITBAND_PERI(CS->rSTAT.r, ACLK_READY_OFS))
            ;

        break;
    }
    case CS_MCLK:
    {

        /* Waiting for the clock source ready bit to be valid before
         * changing */
        while (!BITBAND_PERI(CS->rSTAT.r, MCLK_READY_OFS))
            ;

        CS->rCTL1.r = ((clockSourceDivider >> CS_MCLK_DIV_BITPOS)
                | (clockSource << CS_MCLK_SRC_BITPOS))
                | (CS->rCTL1.r & ~(CS_CTL1_SELM__M | CS_CTL1_DIVM__M));

        /* Waiting for MCLK to be ready */
        while (!BITBAND_PERI(CS->rSTAT.r, MCLK_READY_OFS))
            ;

        break;
    }
    case CS_SMCLK:
    {
        /* Waiting for the clock source ready bit to be valid before
         * changing */
        while (!BITBAND_PERI(CS->rSTAT.r, SMCLK_READY_OFS))
            ;

        CS->rCTL1.r = ((clockSourceDivider >> CS_SMCLK_DIV_BITPOS)
                | (clockSource << CS_HSMCLK_SRC_BITPOS))
                | (CS->rCTL1.r & ~(CS_CTL1_DIVS__M | CS_CTL1_SELS__M));

        /* Waiting for SMCLK to be ready */
        while (!BITBAND_PERI(CS->rSTAT.r, SMCLK_READY_OFS))
            ;

        break;
    }
    case CS_HSMCLK:
    {
        /* Waiting for the clock source ready bit to be valid before
         * changing */
        while (!BITBAND_PERI(CS->rSTAT.r, HSMCLK_READY_OFS))
            ;

        CS->rCTL1.r = ((clockSourceDivider >> CS_HSMCLK_DIV_BITPOS)
                | (clockSource << CS_HSMCLK_SRC_BITPOS))
                | (CS->rCTL1.r & ~(CS_CTL1_DIVHS__M | CS_CTL1_SELS__M));

        /* Waiting for HSMCLK to be ready */
        while (!BITBAND_PERI(CS->rSTAT.r, HSMCLK_READY_OFS))
            ;

        break;
    }
    case CS_BCLK:
    {

        /* Waiting for the clock source ready bit to be valid before
         * changing */
        while (!BITBAND_PERI(CS->rSTAT.r, BCLK_READY_OFS))
            ;

        /* Setting the clock source and then returning
         * (cannot divide CLK)
         */
        if (clockSource == CS_LFXTCLK_SELECT)
            BITBAND_PERI(CS->rCTL1.r, SELB_OFS) = 0;
        else if (clockSource == CS_REFOCLK_SELECT)
            BITBAND_PERI(CS->rCTL1.r, SELB_OFS) = 1;
        else
            ASSERT(false);

        /* Waiting for BCLK to be ready */
        while (!BITBAND_PERI(CS->rSTAT.r, BCLK_READY_OFS))
            ;

        break;
    }
    default:
    {
        /* Should never get here */
        ASSERT(false);
    }
    }

    /* Locking the module */
    BITBAND_PERI(CS->rACC.r, CSKEY_OFS) = 1;
}

void CS_startHFXT(bool bypassMode)
{
    CS_startHFXTWithTimeout(bypassMode, 0);
}

void CS_startHFXTWithTimeout(bool bypassMode, uint32_t timeout)
{
    uint32_t wHFFreqRange;
    uint8_t bNMIStatus;
    bool boolTimeout;

    /* Unlocking the CS Module */
    CS->rACC.r = CS_KEY;

    /* Saving status and temporarily disabling NMIs for UCS faults */
    bNMIStatus = SysCtl_getNMISourceStatus() & SYSCTL_CS_SRC;
    SysCtl_disableNMISource(SYSCTL_CS_SRC);

    /* Determining which frequency range to use */
    wHFFreqRange = __CSGetHFXTFrequency();
    boolTimeout = (timeout == 0) ? false : true;

    /* Setting to maximum drive strength  */
    BITBAND_PERI(CS->rCTL2.r, HFXTDRIVE_OFS) = 1;
    CS->rCTL2.r = (CS->rCTL2.r & (~CS_CTL2_HFXTFREQ__M)) | (wHFFreqRange);

    if (bypassMode)
    {
        BITBAND_PERI(CS->rCTL2.r, HFXTBYPASS_OFS) = 1;
    } else
    {
        BITBAND_PERI(CS->rCTL2.r, HFXTBYPASS_OFS) = 0;
    }

    /* Starting and Waiting for frequency stabilization */
    BITBAND_PERI(CS->rCTL2.r, HFXT_EN_OFS) = 1;
    while (BITBAND_PERI(CS->rIFG.r, HFXTIFG_OFS))
    {
        if (boolTimeout && ((--timeout) == 0))
            break;

        BITBAND_PERI(CS->rCLRIFG.r,CLR_HFXTIFG_OFS) = 0;
    }

    /* Setting the drive strength */
    if (!bypassMode)
    {
        if (wHFFreqRange != CS_CTL2_HFXTFREQ__0)
            BITBAND_PERI(CS->rCTL2.r, HFXTDRIVE_OFS) = 1;
        else
            BITBAND_PERI(CS->rCTL2.r, HFXTDRIVE_OFS) = 0;
    }

    /* Locking the module */
    BITBAND_PERI(CS->rACC.r, CSKEY_OFS) = 1;

    /* Enabling the NMI state */
    SysCtl_enableNMISource(bNMIStatus);

}

void CS_startLFXT(uint32_t xtDrive)
{
    CS_startLFXTWithTimeout(xtDrive, 0);
}

void CS_startLFXTWithTimeout(uint32_t xtDrive, uint32_t timeout)
{
    uint8_t bNMIStatus;
    bool boolBypassMode, boolTimeout;

    ASSERT(lfxtFreq != 0)
    ASSERT(
            (xtDrive == CS_LFXT_DRIVE0) || (xtDrive == CS_LFXT_DRIVE1)
            || (xtDrive == CS_LFXT_DRIVE2)
            || (xtDrive == CS_LFXT_DRIVE3)
            || (xtDrive == CS_LFXT_BYPASS));

    /* Unlocking the CS Module */
    CS->rACC.r = CS_KEY;

    /* Saving status and temporarily disabling NMIs for UCS faults */
    bNMIStatus = SysCtl_getNMISourceStatus() & SYSCTL_CS_SRC;
    SysCtl_disableNMISource(SYSCTL_CS_SRC);
    boolBypassMode = (xtDrive == CS_LFXT_BYPASS) ? true : false;
    boolTimeout = (timeout == 0) ? false : true;

    /* Setting to maximum drive strength  */
    if (boolBypassMode)
    {
        BITBAND_PERI(CS->rCTL2.r, LFXTBYPASS_OFS) = 1;
    } else
    {
        CS->rCTL2.r |= (CS_LFXT_DRIVE3);
        BITBAND_PERI(CS->rCTL2.r, LFXTBYPASS_OFS) = 0;
    }

    /* Waiting for frequency stabilization */
    BITBAND_PERI(CS->rCTL2.r, LFXT_EN_OFS) = 1;

    while (BITBAND_PERI(CS->rIFG.r, LFXTIFG_OFS))
    {
        if (boolTimeout && ((--timeout) == 0))
            break;

        BITBAND_PERI(CS->rCLRIFG.r,CLR_LFXTIFG_OFS) = 0;
    }

    /* Setting the drive strength */
    if (!boolBypassMode)
    {
        CS->rCTL2.r = ((CS->rCTL2.r & ~CS_LFXT_DRIVE3) | xtDrive);
    }

    /* Locking the module */
    BITBAND_PERI(CS->rACC.r, CSKEY_OFS) = 1;

    /* Enabling the NMI state */
    SysCtl_enableNMISource(bNMIStatus);
}

void CS_enableClockRequest(uint32_t selectClock)
{
    ASSERT(
            selectClock == CS_ACLK || selectClock == CS_HSMCLK
            || selectClock == CS_SMCLK || selectClock == CS_MCLK);

    /* Unlocking the module */
    CS->rACC.r = CS_KEY;

    CS->rCLKEN.r |= selectClock;

    /* Locking the module */
    BITBAND_PERI(CS->rACC.r, CSKEY_OFS) = 1;
}

void CS_disableClockRequest(uint32_t selectClock)
{
    ASSERT(
            selectClock == CS_ACLK || selectClock == CS_HSMCLK
            || selectClock == CS_SMCLK || selectClock == CS_MCLK);

    /* Unlocking the module */
    CS->rACC.r = CS_KEY;

    CS->rCLKEN.r &= ~selectClock;

    /* Locking the module */
    BITBAND_PERI(CS->rACC.r, CSKEY_OFS) = 1;
}

void CS_setReferenceOscillatorFrequency(uint8_t referenceFrequency)
{
    ASSERT(
            referenceFrequency == CS_REFO_32KHZ
            || referenceFrequency == CS_REFO_128KHZ);

    /* Unlocking the module */
    CS->rACC.r = CS_KEY;

    BITBAND_PERI(CS->rCLKEN.r, REFOFSEL_OFS) = referenceFrequency;

    /* Locking the module */
    BITBAND_PERI(CS->rACC.r, CSKEY_OFS) = 1;
}

void CS_enableDCOExternalResistor(void)
{
    /* Unlocking the module */
    CS->rACC.r = CS_KEY;

    BITBAND_PERI(CS->rCTL0.r,DCORES_OFS) = 1;

    /* Locking the module */
    BITBAND_PERI(CS->rACC.r, CSKEY_OFS) = 1;
}

void CS_setDCOExternalResistorCalibration(uint_fast8_t uiCalData)
{
    CS->rDCOERCAL.r = (uiCalData);
}

void CS_disableDCOExternalResistor(void)
{
    /* Unlocking the module */
    CS->rACC.r = CS_KEY;

    BITBAND_PERI(CS->rCTL0.r,DCORES_OFS) = 0;

    /* Locking the module */
    BITBAND_PERI(CS->rACC.r, CSKEY_OFS) = 1;
}

void CS_setDCOCenteredFrequency(uint32_t dcoFreq)
{
    ASSERT(
            dcoFreq == CS_DCO_FREQUENCY_1_5 || dcoFreq == CS_DCO_FREQUENCY_3
            || dcoFreq == CS_DCO_FREQUENCY_6
            || dcoFreq == CS_DCO_FREQUENCY_12
            || dcoFreq == CS_DCO_FREQUENCY_24
            || dcoFreq == CS_DCO_FREQUENCY_48);

    /* Unlocking the CS Module */
    CS->rACC.r = CS_KEY;

    /* Resetting Tuning Parameters and Setting the frequency */
    CS->rCTL0.r = ((CS->rCTL0.r & ~CS_CTL0_DCORSEL__M) | dcoFreq);

    /* Locking the CS Module */
    BITBAND_PERI(CS->rACC.r, CSKEY_OFS) = 1;
}

/*void CS_tuneDCOFrequency(int16_t tuneParameter)
{
    CS->rACC.r = CS_KEY;

    CS->rCTL0.r = ((CS->rCTL0.r & ~CS_CTL0_DCOTUNE__M)
            | (tuneParameter & CS_CTL0_DCOTUNE__M));

    BITBAND_PERI(CS->rACC.r, CSKEY_OFS) = 1;
}*/

uint32_t CS_getDCOFrequency(void)
{
    float dcoConst;
    int32_t dcoCal;
    int16_t dcoTune;

    dcoTune = CS->rCTL0.b.bDCOTUNE;

    if (dcoTune == 0)
        return __CSGetDOCFrequency();

    /* Checking to see if we need to do signed conversion */
    if (dcoTune & 0x1000)
    {
        dcoTune = dcoTune | 0xF000;
    }

    dcoConst = (*((volatile float *) (__DDDS_BASE__ + OFS_DDDS_CSDCOCONST)));

    if (BITBAND_PERI(CS->rCTL0.r, DCORES_OFS))
    {
        dcoCal = CS->rDCOERCAL.b.bDCO_FTRIM;
    } else
    {

        dcoCal = (DDDS->rCSDCOIRCAL & CS_DCOERCAL_DCO_FTRIM__M) >> 16;
    }

    return (uint32_t) ((__CSGetDOCFrequency())
            * (1 - (dcoConst * (dcoTune) / 8 * (1 + dcoConst * (1024 - dcoCal)))));
}

/*void CS_setDCOFrequency(uint32_t dcoFrequency)
{
    int32_t nomFreq, calVal;
    int16_t dcoTune;
    float dcoConst;

    if (dcoFrequency < 2000000)
    {
        nomFreq = CS_15MHZ;
        CS_setDCOCenteredFrequency(CS_DCO_FREQUENCY_1_5);
    } else if (dcoFrequency < 4000000)
    {
        nomFreq = CS_3MHZ;
        CS_setDCOCenteredFrequency(CS_DCO_FREQUENCY_3);
    } else if (dcoFrequency < 8000000)
    {
        nomFreq = CS_6MHZ;
        CS_setDCOCenteredFrequency(CS_DCO_FREQUENCY_6);
    } else if (dcoFrequency < 16000000)
    {
        nomFreq = CS_12MHZ;
        CS_setDCOCenteredFrequency(CS_DCO_FREQUENCY_12);
    } else if (dcoFrequency < 32000000)
    {
        nomFreq = CS_24MHZ;
        CS_setDCOCenteredFrequency(CS_DCO_FREQUENCY_24);
    } else if (dcoFrequency < 640000001)
    {
        nomFreq = CS_48MHZ;
        CS_setDCOCenteredFrequency(CS_DCO_FREQUENCY_48);
    } else
    {
        ASSERT(false);
        return;
    }

    if (BITBAND_PERI(CS->rCTL0.r, DCORES_OFS))
    {
        calVal = CS->rDCOERCAL.b.bDCO_FTRIM;
    } else
    {
        calVal = (DDDS->rCSDCOERCAL & CS_DCOERCAL_DCO_FTRIM__M) >> 16;
    }

    dcoConst = (*((volatile float *) (__DDDS_BASE__ + OFS_DDDS_CSDCOCONST)));

    dcoTune = (int16_t) ((8 * (dcoFrequency - nomFreq))
            / (nomFreq * dcoConst * (dcoConst * (calVal - 1024) - 1)));
    CS_tuneDCOFrequency(dcoTune);

}*/

uint32_t CS_getBCLK(void)
{
    if (BITBAND_PERI(CS->rCTL1.r, SELB_OFS))
        return __CSComputeCLKFrequency(CS_REFOCLK_SELECT, CS_CLOCK_DIVIDER_1);
    else
        return __CSComputeCLKFrequency(CS_LFXTCLK_SELECT, CS_CLOCK_DIVIDER_1);
}

uint32_t CS_getHSMCLK(void)
{
    uint32_t wSource, wDivider;

    wSource = (CS->rCTL1.r & CS_CTL1_SELS__M) >> CS_HSMCLK_SRC_BITPOS;
    wDivider = ((CS->rCTL1.r & CS_CTL1_DIVHS__M) << CS_HSMCLK_DIV_BITPOS);

    return __CSComputeCLKFrequency(wSource, wDivider);
}

uint32_t CS_getACLK(void)
{
    uint32_t wSource, wDivider;

    wSource = (CS->rCTL1.r & CS_CTL1_SELA__M) >> CS_ACLK_SRC_BITPOS;
    wDivider = ((CS->rCTL1.r & CS_CTL1_DIVA__M) << CS_ACLK_DIV_BITPOS);

    return __CSComputeCLKFrequency(wSource, wDivider);
}

uint32_t CS_getSMCLK(void)
{
    uint32_t wDivider, wSource;

    wSource = (CS->rCTL1.r & CS_CTL1_SELS__M) >> CS_HSMCLK_SRC_BITPOS;
    wDivider = ((CS->rCTL1.r & CS_CTL1_DIVS__M));

    return __CSComputeCLKFrequency(wSource, wDivider);

}

uint32_t CS_getMCLK(void)
{
    uint32_t wSource, wDivider;

    wSource = (CS->rCTL1.r & CS_CTL1_SELM__M) << CS_MCLK_SRC_BITPOS;
    wDivider = ((CS->rCTL1.r & CS_CTL1_DIVM__M) << CS_MCLK_DIV_BITPOS);

    return __CSComputeCLKFrequency(wSource, wDivider);
}

void CS_enableFaultCounter(uint_fast8_t counterSelect)
{
    ASSERT(counterSelect == CS_HFXT_FAULT_COUNTER ||
            counterSelect == CS_HFXT_FAULT_COUNTER);

    /* Unlocking the module */
    CS->rACC.r = CS_KEY;

    if (counterSelect == CS_HFXT_FAULT_COUNTER)
    {
        BITBAND_PERI(CS->rCTL3.r, FCNTHF_EN_OFS) = 1;
    } else
    {
        BITBAND_PERI(CS->rCTL3.r, FCNTLF_EN_OFS) = 1;
    }

    /* Locking the module */
    BITBAND_PERI(CS->rACC.r, CSKEY_OFS) = 1;
}

void CS_disableFaultCounter(uint_fast8_t counterSelect)
{
    ASSERT(counterSelect == CS_HFXT_FAULT_COUNTER ||
            counterSelect == CS_HFXT_FAULT_COUNTER);

    /* Unlocking the module */
    CS->rACC.r = CS_KEY;

    if (counterSelect == CS_HFXT_FAULT_COUNTER)
    {
        BITBAND_PERI(CS->rCTL3.r, FCNTHF_EN_OFS) = 0;
    } else
    {
        BITBAND_PERI(CS->rCTL3.r, FCNTLF_EN_OFS) = 0;
    }

    /* Locking the module */
    BITBAND_PERI(CS->rACC.r, CSKEY_OFS) = 1;
}

void CS_resetFaultCounter(uint_fast8_t counterSelect)
{
    ASSERT(counterSelect == CS_HFXT_FAULT_COUNTER ||
            counterSelect == CS_HFXT_FAULT_COUNTER);

    /* Unlocking the module */
    CS->rACC.r = CS_KEY;

    if (counterSelect == CS_HFXT_FAULT_COUNTER)
    {
        BITBAND_PERI(CS->rCTL3.r, RFCNTHF_OFS) = 1;
    } else
    {
        BITBAND_PERI(CS->rCTL3.r, RFCNTLF_OFS) = 1;
    }

    /* Locking the module */
    BITBAND_PERI(CS->rACC.r, CSKEY_OFS) = 1;
}

void CS_startFaultCounter(uint_fast8_t counterSelect, uint_fast8_t countValue)
{
    ASSERT(counterSelect == CS_HFXT_FAULT_COUNTER ||
            counterSelect == CS_HFXT_FAULT_COUNTER);

    ASSERT(countValue == CS_FAULT_COUNTER_4096_CYCLES ||
            countValue == CS_FAULT_COUNTER_8192_CYCLES ||
            countValue == CS_FAULT_COUNTER_16384_CYCLES ||
            countValue == CS_FAULT_COUNTER_32768_CYCLES);

    /* Unlocking the module */
    CS->rACC.r = CS_KEY;

    if (counterSelect == CS_HFXT_FAULT_COUNTER)
    {
        CS->rCTL3.r = ((CS->rCTL3.r & ~CS_CTL3_FCNTHF__M) | (countValue << 4));
    } else
    {
        CS->rCTL3.r = ((CS->rCTL3.r & ~CS_CTL3_FCNTLF__M) | (countValue));
    }

    /* Locking the module */
    BITBAND_PERI(CS->rACC.r, CSKEY_OFS) = 1;
}

void CS_enableInterrupt(uint32_t flags)
{
    /* Unlocking the module */
    CS->rACC.r = CS_KEY;

    CS->rIE.r |= flags;

    /* Locking the module */
    BITBAND_PERI(CS->rACC.r, CSKEY_OFS) = 1;
}

void CS_disableInterrupt(uint32_t flags)
{
    /* Unlocking the module */
    CS->rACC.r = CS_KEY;

    CS->rIE.r &= ~flags;

    /* Locking the module */
    BITBAND_PERI(CS->rACC.r, CSKEY_OFS) = 1;
}

uint32_t CS_getInterruptStatus(void)
{
    return CS->rIFG.r;
}

uint32_t CS_getEnabledInterruptStatus(void)
{
    return CS_getInterruptStatus() & CS->rIE.r;
}

void CS_clearInterruptFlag(uint32_t flags)
{
    /* Unlocking the module */
    CS->rACC.r = CS_KEY;

    CS->rCLRIFG.r |= flags;

    /* Locking the module */
    BITBAND_PERI(CS->rACC.r, CSKEY_OFS) = 1;
}

void CS_registerInterrupt(void (*intHandler)(void))
{
    //
    // Register the interrupt handler, returning an error if an error occurs.
    //
    Interrupt_registerInterrupt(INT_CS, intHandler);

    //
    // Enable the system control interrupt.
    //
    Interrupt_enableInterrupt(INT_CS);
}

void CS_unregisterInterrupt(void)
{
    //
    // Disable the interrupt.
    //
    Interrupt_disableInterrupt(INT_CS);

    //
    // Unregister the interrupt handler.
    //
    Interrupt_unregisterInterrupt(INT_CS);
}

