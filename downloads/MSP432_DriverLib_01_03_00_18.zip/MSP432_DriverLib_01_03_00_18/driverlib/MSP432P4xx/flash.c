/*
 * -------------------------------------------
 *    MSP432 DriverLib - v01_03_00_18 
 * -------------------------------------------
 *
 * --COPYRIGHT--,BSD,BSD
 * Copyright (c) 2014, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
/* Standard Includes */
#include <stdint.h>
#include "register_remap.h"
#include <msp430dna.h>

/* DriverLib Includes */
#include <flash.h>
#include <debug.h>
#include <interrupt.h>
#include <msp432.h>
#include <cpu.h>
#include <sysctl.h>

/* Statics */
static uint32_t getBurstProgramRegs(uint8_t bIndex)
{
    switch (bIndex)
    {
    case 0:
        return OFS_FLCTL_PRGBRST_DATA0_0;
    case 1:
        return OFS_FLCTL_PRGBRST_DATA0_1;
    case 2:
        return OFS_FLCTL_PRGBRST_DATA0_2;
    case 3:
        return OFS_FLCTL_PRGBRST_DATA0_3;
    case 4:
        return OFS_FLCTL_PRGBRST_DATA1_0;
    case 5:
        return OFS_FLCTL_PRGBRST_DATA1_1;
    case 6:
        return OFS_FLCTL_PRGBRST_DATA1_2;
    case 7:
        return OFS_FLCTL_PRGBRST_DATA1_3;
    case 8:
        return OFS_FLCTL_PRGBRST_DATA2_0;
    case 9:
        return OFS_FLCTL_PRGBRST_DATA2_1;
    case 10:
        return OFS_FLCTL_PRGBRST_DATA2_2;
    case 11:
        return OFS_FLCTL_PRGBRST_DATA2_3;
    case 12:
        return OFS_FLCTL_PRGBRST_DATA3_0;
    case 13:
        return OFS_FLCTL_PRGBRST_DATA3_1;
    case 14:
        return OFS_FLCTL_PRGBRST_DATA3_2;
    case 15:
        return OFS_FLCTL_PRGBRST_DATA3_3;
    default:
        ASSERT(false);
        return 0;
    }
}

static uint32_t getUserFlashSector(uint32_t addr)
{
    if (addr > 0x1ffff)
    {
        addr = addr - 0x20000;
    }

    switch (addr)
    {
    case 0:
        return FLASH_SECTOR0;
    case 0x1000:
        return FLASH_SECTOR1;
    case 0x2000:
        return FLASH_SECTOR2;
    case 0x3000:
        return FLASH_SECTOR3;
    case 0x4000:
        return FLASH_SECTOR4;
    case 0x5000:
        return FLASH_SECTOR5;
    case 0x6000:
        return FLASH_SECTOR6;
    case 0x7000:
        return FLASH_SECTOR7;
    case 0x8000:
        return FLASH_SECTOR8;
    case 0x9000:
        return FLASH_SECTOR9;
    case 0xA000:
        return FLASH_SECTOR10;
    case 0xB000:
        return FLASH_SECTOR11;
    case 0xC000:
        return FLASH_SECTOR12;
    case 0xD000:
        return FLASH_SECTOR13;
    case 0xE000:
        return FLASH_SECTOR14;
    case 0xF000:
        return FLASH_SECTOR15;
    case 0x10000:
        return FLASH_SECTOR16;
    case 0x11000:
        return FLASH_SECTOR17;
    case 0x12000:
        return FLASH_SECTOR18;
    case 0x13000:
        return FLASH_SECTOR19;
    case 0x14000:
        return FLASH_SECTOR20;
    case 0x15000:
        return FLASH_SECTOR21;
    case 0x16000:
        return FLASH_SECTOR22;
    case 0x17000:
        return FLASH_SECTOR23;
    case 0x18000:
        return FLASH_SECTOR24;
    case 0x19000:
        return FLASH_SECTOR25;
    case 0x1A000:
        return FLASH_SECTOR26;
    case 0x1B000:
        return FLASH_SECTOR27;
    case 0x1C000:
        return FLASH_SECTOR28;
    case 0x1D000:
        return FLASH_SECTOR29;
    case 0x1E000:
        return FLASH_SECTOR30;
    case 0x1F000:
        return FLASH_SECTOR31;
    default:
        ASSERT(false);
        return 0;
    }
}

#ifdef BUILD_FOR_ROM
static uint32_t __getFlashBank(uint32_t addr)
{
    if ((addr < (__FLASH_START__ + 0x20000))
            || ((addr > __FLASH_END__) &&
                    (addr < (__INFO_FLASH_START__ + 0x2000))))
    return FLASH_BANK0;
    else
    return FLASH_BANK1;
}
#endif

void FlashCtl_enableReadParityCheck(uint_fast8_t memorySpace,
        uint_fast8_t accessMethod)
{
    if (memorySpace == FLASH_MAIN_MEMORY_SPACE_BANK0
            && accessMethod == FLASH_DATA_READ)
        BITBAND_PERI(FLCTL->rRDCTL_BNK0.r, FLCTL_RDCTL_BNK0_MAIN_PARD_OFS) = 1;
    else if (memorySpace == FLASH_MAIN_MEMORY_SPACE_BANK1
            && accessMethod == FLASH_DATA_READ)
        BITBAND_PERI(FLCTL->rRDCTL_BNK1.r, FLCTL_RDCTL_BNK1_MAIN_PARD_OFS) = 1;
    else if (memorySpace == FLASH_MAIN_MEMORY_SPACE_BANK0
            && accessMethod == FLASH_INSTRUCTION_FETCH)
        BITBAND_PERI(FLCTL->rRDCTL_BNK0.r, FLCTL_RDCTL_BNK0_MAIN_PARI_OFS) = 1;
    else if (memorySpace == FLASH_MAIN_MEMORY_SPACE_BANK1
            && accessMethod == FLASH_INSTRUCTION_FETCH)
        BITBAND_PERI(FLCTL->rRDCTL_BNK1.r, FLCTL_RDCTL_BNK1_MAIN_PARI_OFS) = 1;
    else if (memorySpace == FLASH_INFO_MEMORY_SPACE_BANK0
            && accessMethod == FLASH_DATA_READ)
        BITBAND_PERI(FLCTL->rRDCTL_BNK0.r, FLCTL_RDCTL_BNK0_INFO_PARD_OFS) = 1;
    else if (memorySpace == FLASH_INFO_MEMORY_SPACE_BANK1
            && accessMethod == FLASH_DATA_READ)
        BITBAND_PERI(FLCTL->rRDCTL_BNK1.r, FLCTL_RDCTL_BNK1_INFO_PARD_OFS) = 1;
    else if (memorySpace == FLASH_INFO_MEMORY_SPACE_BANK0
            && accessMethod == FLASH_INSTRUCTION_FETCH)
        BITBAND_PERI(FLCTL->rRDCTL_BNK0.r, FLCTL_RDCTL_BNK0_INFO_PARI_OFS) = 1;
    else if (memorySpace == FLASH_INFO_MEMORY_SPACE_BANK1
            && accessMethod == FLASH_INSTRUCTION_FETCH)
        BITBAND_PERI(FLCTL->rRDCTL_BNK1.r, FLCTL_RDCTL_BNK1_INFO_PARI_OFS) = 1;
    else
        ASSERT(false);
}

void FlashCtl_disableReadParityCheck(uint_fast8_t memorySpace,
        uint_fast8_t accessMethod)
{
    if (memorySpace == FLASH_MAIN_MEMORY_SPACE_BANK0
            && accessMethod == FLASH_DATA_READ)
        BITBAND_PERI(FLCTL->rRDCTL_BNK0.r, FLCTL_RDCTL_BNK0_MAIN_PARD_OFS) = 0;
    else if (memorySpace == FLASH_MAIN_MEMORY_SPACE_BANK1
            && accessMethod == FLASH_DATA_READ)
        BITBAND_PERI(FLCTL->rRDCTL_BNK1.r, FLCTL_RDCTL_BNK1_MAIN_PARD_OFS) = 0;
    else if (memorySpace == FLASH_MAIN_MEMORY_SPACE_BANK0
            && accessMethod == FLASH_INSTRUCTION_FETCH)
        BITBAND_PERI(FLCTL->rRDCTL_BNK0.r, FLCTL_RDCTL_BNK0_MAIN_PARI_OFS) = 0;
    else if (memorySpace == FLASH_MAIN_MEMORY_SPACE_BANK1
            && accessMethod == FLASH_INSTRUCTION_FETCH)
        BITBAND_PERI(FLCTL->rRDCTL_BNK1.r, FLCTL_RDCTL_BNK1_MAIN_PARI_OFS) = 0;
    else if (memorySpace == FLASH_INFO_MEMORY_SPACE_BANK0
            && accessMethod == FLASH_DATA_READ)
        BITBAND_PERI(FLCTL->rRDCTL_BNK0.r, FLCTL_RDCTL_BNK0_INFO_PARD_OFS) = 0;
    else if (memorySpace == FLASH_INFO_MEMORY_SPACE_BANK1
            && accessMethod == FLASH_DATA_READ)
        BITBAND_PERI(FLCTL->rRDCTL_BNK1.r, FLCTL_RDCTL_BNK1_INFO_PARD_OFS) = 0;
    else if (memorySpace == FLASH_INFO_MEMORY_SPACE_BANK0
            && accessMethod == FLASH_INSTRUCTION_FETCH)
        BITBAND_PERI(FLCTL->rRDCTL_BNK0.r, FLCTL_RDCTL_BNK0_INFO_PARI_OFS) = 0;
    else if (memorySpace == FLASH_INFO_MEMORY_SPACE_BANK1
            && accessMethod == FLASH_INSTRUCTION_FETCH)
        BITBAND_PERI(FLCTL->rRDCTL_BNK1.r, FLCTL_RDCTL_BNK1_INFO_PARI_OFS) = 0;
    else
        ASSERT(false);
}

void FlashCtl_enableReadBuffering(uint_fast8_t memoryBank,
        uint_fast8_t accessMethod)
{
    if (memoryBank == FLASH_BANK0 && accessMethod == FLASH_DATA_READ)
        BITBAND_PERI(FLCTL->rRDCTL_BNK0.r, FLCTL_RDCTL_BNK0_BUFD_OFS) = 1;
    else if (memoryBank == FLASH_BANK1 && accessMethod == FLASH_DATA_READ)
        BITBAND_PERI(FLCTL->rRDCTL_BNK1.r, FLCTL_RDCTL_BNK1_BUFD_OFS) = 1;
    else if (memoryBank == FLASH_BANK0
            && accessMethod == FLASH_INSTRUCTION_FETCH)
        BITBAND_PERI(FLCTL->rRDCTL_BNK0.r, FLCTL_RDCTL_BNK0_BUFI_OFS) = 1;
    else if (memoryBank == FLASH_BANK1
            && accessMethod == FLASH_INSTRUCTION_FETCH)
        BITBAND_PERI(FLCTL->rRDCTL_BNK1.r, FLCTL_RDCTL_BNK1_BUFI_OFS) = 1;
    else
        ASSERT(false);
}

void FlashCtl_disableReadBuffering(uint_fast8_t memoryBank,
        uint_fast8_t accessMethod)
{
    if (memoryBank == FLASH_BANK0 && accessMethod == FLASH_DATA_READ)
        BITBAND_PERI(FLCTL->rRDCTL_BNK0.r, FLCTL_RDCTL_BNK0_BUFD_OFS) = 0;
    else if (memoryBank == FLASH_BANK1 && accessMethod == FLASH_DATA_READ)
        BITBAND_PERI(FLCTL->rRDCTL_BNK1.r, FLCTL_RDCTL_BNK1_BUFD_OFS) = 0;
    else if (memoryBank == FLASH_BANK0
            && accessMethod == FLASH_INSTRUCTION_FETCH)
        BITBAND_PERI(FLCTL->rRDCTL_BNK0.r, FLCTL_RDCTL_BNK0_BUFI_OFS) = 0;
    else if (memoryBank == FLASH_BANK1
            && accessMethod == FLASH_INSTRUCTION_FETCH)
        BITBAND_PERI(FLCTL->rRDCTL_BNK1.r, FLCTL_RDCTL_BNK1_BUFI_OFS) = 0;
    else
        ASSERT(false);
}

bool FlashCtl_unprotectSector(uint_fast8_t memorySpace, uint32_t sectorMask)
{
    switch (memorySpace)
    {
    case FLASH_MAIN_MEMORY_SPACE_BANK0:
        FLCTL->rMAINWEPROT_BNK0.r &= ~sectorMask;
        break;
    case FLASH_MAIN_MEMORY_SPACE_BANK1:
        FLCTL->rMAINWEPROT_BNK1.r &= ~sectorMask;
        break;
    case FLASH_INFO_MEMORY_SPACE_BANK0:
        ASSERT(sectorMask <= 0x04);
        FLCTL->rINFOWEPROT_BNK0.r &= ~sectorMask;
        break;
    case FLASH_INFO_MEMORY_SPACE_BANK1:
        ASSERT(sectorMask <= 0x04);
        FLCTL->rINFOWEPROT_BNK1.r &= ~sectorMask;
        break;

    default:
        ASSERT(false);

    }

    return !FlashCtl_isSectorProtected(memorySpace, sectorMask);
}

bool FlashCtl_protectSector(uint_fast8_t memorySpace, uint32_t sectorMask)
{
    switch (memorySpace)
    {
    case FLASH_MAIN_MEMORY_SPACE_BANK0:
        FLCTL->rMAINWEPROT_BNK0.r |= sectorMask;
        break;
    case FLASH_MAIN_MEMORY_SPACE_BANK1:
        FLCTL->rMAINWEPROT_BNK1.r |= sectorMask;
        break;
    case FLASH_INFO_MEMORY_SPACE_BANK0:
        ASSERT(sectorMask <= 0x04);
        FLCTL->rINFOWEPROT_BNK0.r |= sectorMask;
        break;
    case FLASH_INFO_MEMORY_SPACE_BANK1:
        ASSERT(sectorMask <= 0x04);
        FLCTL->rINFOWEPROT_BNK1.r |= sectorMask;
        break;

    default:
        ASSERT(false);

    }

    return FlashCtl_isSectorProtected(memorySpace, sectorMask);
}

bool FlashCtl_isSectorProtected(uint_fast8_t memorySpace, uint32_t sector)
{
    switch (memorySpace)
    {
    case FLASH_MAIN_MEMORY_SPACE_BANK0:
        return FLCTL->rMAINWEPROT_BNK0.r & sector;
    case FLASH_MAIN_MEMORY_SPACE_BANK1:
        return FLCTL->rMAINWEPROT_BNK1.r & sector;
    case FLASH_INFO_MEMORY_SPACE_BANK0:
        ASSERT(sector <= 0x04);
        return FLCTL->rINFOWEPROT_BNK0.r & sector;
    case FLASH_INFO_MEMORY_SPACE_BANK1:
        ASSERT(sector <= 0x04);
        return FLCTL->rINFOWEPROT_BNK1.r & sector;
    default:
        return false;
    }
}

bool FlashCtl_verifyMemory(void* verifyAddr, uint32_t length,
        uint_fast8_t pattern)
{
    uint32_t memoryPattern, addr, otpOffset;
    uint_fast8_t memoryType;

    ASSERT(pattern == FLASH_0_PATTERN || pattern == FLASH_1_PATTERN);

    addr = (uint32_t) verifyAddr;
    memoryPattern = (pattern == FLASH_1_PATTERN) ? 0xFFFFFFFF : 0;
    memoryType = (addr > __FLASH_END__) ? FLASH_INFO_SPACE : FLASH_MAIN_SPACE;

    /* Taking care of byte accesses */
    while ((addr & 0x03) && (length > 0))
    {
        if (HWREG8(addr++) != ((uint8_t) memoryPattern))
            return false;
        length--;
    }

    /* Making sure we are aligned by 128-bit address */
    while (((addr & 0x0F)) && (length > 3))
    {
        if (HWREG32(addr) != memoryPattern)
            return false;

        addr = addr + 4;
        length = length - 4;
    }

    /* Burst Verify */
    if (length > 63)
    {

        /* Setting/clearing INFO flash flags as appropriate */
        if (addr > __FLASH_START__)
        {
            FLCTL->rRDBRST_CTLSTAT.r = (FLCTL->rRDBRST_CTLSTAT.r
                    & ~FLCTL_RDBRST_CTLSTAT_MEM_TYPE__M)
                    | FLCTL_RDBRST_CTLSTAT_MEM_TYPE__1;
            otpOffset = __INFO_FLASH_START__;
        } else
        {
            FLCTL->rRDBRST_CTLSTAT.r = (FLCTL->rRDBRST_CTLSTAT.r
                    & ~FLCTL_RDBRST_CTLSTAT_MEM_TYPE__M)
                    | FLCTL_RDBRST_CTLSTAT_MEM_TYPE__0;
            otpOffset = __FLASH_START__;
        }

        /* Clearing any lingering fault flags  and preparing burst verify*/
        BITBAND_PERI(FLCTL->rRDBRST_CTLSTAT.r, FLCTL_RDBRST_CTLSTAT_CLR_STAT_OFS) =
                1;
        FLCTL->rRDBRST_FAILCNT.r = 0;
        FLCTL->rRDBRST_STARTADDR.r = addr - otpOffset;
        FLCTL->rRDBRST_LEN.r = (length & 0xFFFFFFF0);
        addr += FLCTL->rRDBRST_LEN.r;
        length = length & 0xF;

        /* Starting Burst Verify */
        FLCTL->rRDBRST_CTLSTAT.r = (FLCTL_RDBRST_CTLSTAT_STOP_FAIL | pattern
                | memoryType | FLCTL_RDBRST_CTLSTAT_START);

        /* While the burst read hasn't finished */
        while ((FLCTL->rRDBRST_CTLSTAT.r & FLCTL_RDBRST_CTLSTAT_BRST_STAT__M)
                != FLCTL_RDBRST_CTLSTAT_BRST_STAT__3)
        {
            __no_operation();
        }

        /* Checking  for a verification/access error/failure */
        if (BITBAND_PERI(FLCTL->rRDBRST_CTLSTAT.r,
                FLCTL_RDBRST_CTLSTAT_CMP_ERR_OFS)
                || BITBAND_PERI(FLCTL->rRDBRST_CTLSTAT.r,
                        FLCTL_RDBRST_CTLSTAT_ADDR_ERR_OFS)
                || FLCTL->rRDBRST_FAILCNT.r)
        {
            /* Clearing the Read Burst flag and returning */
            BITBAND_PERI(FLCTL->rRDBRST_CTLSTAT.r, FLCTL_RDBRST_CTLSTAT_CLR_STAT_OFS) =
                    1;
            return false;
        }

        /* Clearing the Read Burst flag */
        BITBAND_PERI(FLCTL->rRDBRST_CTLSTAT.r, FLCTL_RDBRST_CTLSTAT_CLR_STAT_OFS) =
                1;

    }

    /* Remaining Words */
    while (length > 3)
    {
        if (HWREG32(addr) != memoryPattern)
            return false;

        addr = addr + 4;
        length = length - 4;
    }

    /* Remaining Bytes */
    while (length > 0)
    {
        if (HWREG8(addr++) != ((uint8_t) memoryPattern))
            return false;
        length--;
    }

    return true;
}

bool FlashCtl_setReadMode(uint32_t flashBank, uint32_t readMode)
{

    if (FLCTL->rPWRSTAT.r & FLCTL_PWRSTAT_RD_2T)
        return false;

    if (flashBank == FLASH_BANK0)
    {
        FLCTL->rRDCTL_BNK0.r = (FLCTL->rRDCTL_BNK0.r
                & ~FLCTL_RDCTL_BNK0_RD_MODE__M) | readMode;
        while (FLCTL->rRDCTL_BNK0.b.bRD_MODE != readMode)
            ;
    } else if (flashBank == FLASH_BANK1)
    {
        FLCTL->rRDCTL_BNK1.r = (FLCTL->rRDCTL_BNK1.r
                & ~FLCTL_RDCTL_BNK1_RD_MODE__M) | readMode;
        while (FLCTL->rRDCTL_BNK1.b.bRD_MODE != readMode)
            ;
    } else
    {
        ASSERT(false);
        return false;
    }

    return true;
}

uint32_t FlashCtl_getReadMode(uint32_t flashBank)
{
    if (flashBank == FLASH_BANK0)
    {
        return FLCTL->rRDCTL_BNK0.b.bRD_MODE;
    } else if (flashBank == FLASH_BANK1)
    {
        return FLCTL->rRDCTL_BNK1.b.bRD_MODE;
    } else
    {
        ASSERT(false);
        return 0;
    }
}

bool FlashCtl_performMassErase(bool verify)
{
    uint32_t userFlash, ii, sector;

#ifdef BUILD_FOR_ROM
    uint32_t waitStatesB0, waitStatesB1;
#endif

    bool res;

    res = true;

    /* Clearing old mass erase flags */
    BITBAND_PERI(FLCTL->rERASE_CTLSTAT.r, FLCTL_ERASE_CTLSTAT_CLR_STAT_OFS) = 1;

    /* Performing the mass erase */
    FLCTL->rERASE_CTLSTAT.r |= (FLCTL_ERASE_CTLSTAT_MODE
            | FLCTL_ERASE_CTLSTAT_START);

    while ((FLCTL->rERASE_CTLSTAT.r & FLCTL_ERASE_CTLSTAT_STATUS__M)
            == FLCTL_ERASE_CTLSTAT_STATUS__1
            || (FLCTL->rERASE_CTLSTAT.r & FLCTL_ERASE_CTLSTAT_STATUS__M)
                    == FLCTL_ERASE_CTLSTAT_STATUS__2)
        ;
    {

    }
    /* Return false if an address error */
    if (BITBAND_PERI(FLCTL->rERASE_CTLSTAT.r, FLCTL_ERASE_CTLSTAT_ADDR_ERR_OFS))
        return false;

    if (verify)
    {
        /* Changing to erase verify */
#ifdef BUILD_FOR_ROM
        waitStatesB0 = FlashCtl_getWaitState(FLASH_BANK0);
        waitStatesB1 = FlashCtl_getWaitState(FLASH_BANK1);
        FlashCtl_setWaitState(FLASH_BANK0, (waitStatesB0*2)+1);
        FlashCtl_setWaitState(FLASH_BANK1, (waitStatesB1*2)+1);
        FlashCtl_setReadMode(FLASH_BANK0, FLASH_ERASE_VERIFY_READ_MODE);
        FlashCtl_setReadMode(FLASH_BANK1, FLASH_ERASE_VERIFY_READ_MODE);
#endif

        userFlash = SysCtl_getFlashSize() / 2;

        for (ii = __FLASH_START__; ii < userFlash; ii += 4096)
        {
            sector = getUserFlashSector(ii);

            if (!((FLCTL->rMAINWEPROT_BNK0.r) & sector))
            {
                if (!FlashCtl_verifyMemory((void*) ii, 4096, FLASH_1_PATTERN))
                {
                    res = false;
                    break;
                }
            }

            if (!(FLCTL->rMAINWEPROT_BNK1.r & sector))
            {
                if (!FlashCtl_verifyMemory((void*) (ii + userFlash), 4096,
                FLASH_1_PATTERN))
                {
                    res = false;
                    break;
                }
            }

            if (sector < FLCTL_MAINWEPROT_BNK0_PROT2)
            {
                if (!(FLCTL->rINFOWEPROT_BNK0.r & sector))
                {
                    if (!FlashCtl_verifyMemory(
                            (void*) (ii + __INFO_FLASH_START__), 4096,
                            FLASH_1_PATTERN))
                    {
                        res = false;
                        break;
                    }
                }

                if (!(FLCTL->rINFOWEPROT_BNK1.r & sector))
                {
                    if (!FlashCtl_verifyMemory(
                            (void*) (ii + (__INFO_FLASH_START__ + 0x2000)),
                            4096, FLASH_1_PATTERN))
                    {
                        res = false;
                        break;
                    }
                }

            }
        }
#ifdef BUILD_FOR_ROM
        FlashCtl_setWaitState(FLASH_BANK0, waitStatesB0);
        FlashCtl_setWaitState(FLASH_BANK1, waitStatesB1);
        FlashCtl_setReadMode(FLASH_BANK0, FLASH_NORMAL_READ_MODE);
        FlashCtl_setReadMode(FLASH_BANK1, FLASH_NORMAL_READ_MODE);
#endif

        if (res == false)
        {
            return false;
        }
    }

    /* Clear the status bit */
    BITBAND_PERI(FLCTL->rERASE_CTLSTAT.r, FLCTL_ERASE_CTLSTAT_CLR_STAT_OFS) = 1;

    return true;
}

bool FlashCtl_eraseSector(uint32_t addr, bool verify)
{
#ifdef BUILD_FOR_ROM
    uint_fast32_t waitStates, bank;
#endif
    uint_fast8_t memoryType;
    uint32_t otpOffset = 0;

    memoryType = addr > __FLASH_END__ ? FLASH_INFO_SPACE : FLASH_MAIN_SPACE;

    /* We can only erase on 4KB boundaries */
    while (addr & 0xFFF)
    {
        addr--;
    }

    if (memoryType == FLASH_INFO_SPACE)
    {
        otpOffset = __INFO_FLASH_START__;
        FLCTL->rERASE_CTLSTAT.r = (FLCTL->rERASE_CTLSTAT.r
                & ~(FLCTL_ERASE_CTLSTAT_TYPE__M)) | FLCTL_ERASE_CTLSTAT_TYPE__1;

    } else
    {
        otpOffset = __FLASH_START__;
        FLCTL->rERASE_CTLSTAT.r = (FLCTL->rERASE_CTLSTAT.r
                & ~(FLCTL_ERASE_CTLSTAT_TYPE__M)) | FLCTL_ERASE_CTLSTAT_TYPE__0;
    }

    /* Clearing old flags  and setting up the erase */
    BITBAND_PERI(FLCTL->rERASE_CTLSTAT.r, FLCTL_ERASE_CTLSTAT_CLR_STAT_OFS) = 1;
    FLCTL->rINTCLR.r |= (FLASH_BRSTRDCMP_COMPLETE | FLASH_ERASE_COMPLETE);
    BITBAND_PERI(FLCTL->rERASE_CTLSTAT.r, FLCTL_ERASE_CTLSTAT_MODE_OFS) = 0;
    FLCTL->rERASE_SECTADDR.r = addr - otpOffset;

    /* Starting the erase */
    BITBAND_PERI(FLCTL->rERASE_CTLSTAT.r, FLCTL_ERASE_CTLSTAT_START_OFS) = 1;

    while ((FLCTL->rERASE_CTLSTAT.r & FLCTL_ERASE_CTLSTAT_STATUS__M)
            == FLCTL_ERASE_CTLSTAT_STATUS__1
            || (FLCTL->rERASE_CTLSTAT.r & FLCTL_ERASE_CTLSTAT_STATUS__M)
                    == FLCTL_ERASE_CTLSTAT_STATUS__2)
        ;
    {
        __no_operation();
    }

    /* Clearing Erase Flag */
    BITBAND_PERI(FLCTL->rERASE_CTLSTAT.r, FLCTL_ERASE_CTLSTAT_CLR_STAT_OFS) = 1;

    /* Return false if an address error */
    if (BITBAND_PERI(FLCTL->rERASE_CTLSTAT.r, FLCTL_ERASE_CTLSTAT_ADDR_ERR_OFS))
        return false;

    /* Erase verifying */
    if (verify)
    {
        /* Changing to Erase Verify Mode */
#ifdef BUILD_FOR_ROM
        bank = __getFlashBank(addr);
        waitStates = FlashCtl_getWaitState(bank);
        FlashCtl_setWaitState(bank, (waitStates*2)+1);
        FlashCtl_setReadMode(bank, FLASH_ERASE_VERIFY_READ_MODE);
#endif

        if (!FlashCtl_verifyMemory((void*) addr, 4096, FLASH_1_PATTERN))
        {
#ifdef BUILD_FOR_ROM
            FlashCtl_setWaitState(bank, waitStates);
            FlashCtl_setReadMode(bank, FLASH_NORMAL_READ_MODE);
#endif
            return false;
        }

#ifdef BUILD_FOR_ROM
        FlashCtl_setReadMode(bank, FLASH_NORMAL_READ_MODE);
        FlashCtl_setWaitState(bank, waitStates);
#endif

    }

    /* Clearing the status flag */
    BITBAND_PERI(FLCTL->rERASE_CTLSTAT.r, FLCTL_ERASE_CTLSTAT_CLR_STAT_OFS) = 1;

    return true;
}

bool FlashCtl_programMemory(void* src, void* dest, uint32_t length,
        uint32_t verificationSetting)
{
    uint_fast8_t bCalc;
    uint32_t srcAddr, destAddr, otpOffset;
    bool preRegVer, postRegVer, preBrVer, postBrVer;

    /* Asserts  */
    ASSERT(length != 0);

    srcAddr = (uint32_t) src;
    destAddr = (uint32_t) dest;
    preRegVer = (verificationSetting & FLASH_REGPRE) ? true : false;
    postRegVer = (verificationSetting & FLASH_REGPOST) ? true : false;
    preBrVer = (verificationSetting & FLASH_REGPRE) ? true : false;
    postBrVer = (verificationSetting & FLASH_REGPRE) ? true : false;

    FlashCtl_setProgramVerification(verificationSetting);
    FlashCtl_clearProgramVerification(
            ~verificationSetting
                    & (FLASH_REGPRE | FLASH_REGPOST | FLASH_BURSTPOST
                            | FLASH_BURSTPRE));

    /* Clearing old errors */
    FlashCtl_clearInterruptFlag(
    FLASH_WRDPRGM_COMPLETE | FLASH_POSTVERIFY_FAILED | FLASH_PREVERIFY_FAILED);
    BITBAND_PERI(FLCTL->rPRGBRST_CTLSTAT.r, FLCTL_PRGBRST_CTLSTAT_CLR_STAT_OFS) =
            1;
    FLCTL->rINTCLR.r |= (FLASH_PROGRAM_ERROR | FLASH_POSTVERIFY_FAILED
            | FLASH_PREVERIFY_FAILED);

    FlashCtl_enableWordProgramming(FLASH_IMMEDIATE_WRITE_MODE);

    /* Taking care of byte accesses */
    while ((destAddr & 0x03) && length > 0)
    {
        HWREG8(destAddr++) = HWREG8(srcAddr++);
        length--;

        while (!(FlashCtl_getInterruptStatus() & FLASH_WRDPRGM_COMPLETE))
        {
        }

        if ((FlashCtl_getInterruptStatus() & FLASH_PROGRAM_ERROR)
                || (preRegVer
                        && BITBAND_PERI(FLCTL->rINTFLAG.r,
                                FLCTL_INTFLAG_AVPRE_OFS))
                || (postRegVer
                        && BITBAND_PERI(FLCTL->rINTFLAG.r,
                                FLCTL_INTFLAG_AVPST_OFS)))
        {
            FlashCtl_disableWordProgramming();
            return false;
        } else
        {
            BITBAND_PERI(FLCTL->rINTCLR.r, FLCTL_INTCLR_PRG_OFS) = 1;
        }
    }

    /* Making sure we are aligned by 128-bit address */
    while ((destAddr & 0x0F) && (length > 3))
    {
        HWREG32(destAddr) = HWREG32(srcAddr);

        while (!(FlashCtl_getInterruptStatus() & FLASH_WRDPRGM_COMPLETE))
        {
        }

        if ((FlashCtl_getInterruptStatus() & FLASH_PROGRAM_ERROR)
                || (preRegVer
                        && BITBAND_PERI(FLCTL->rINTFLAG.r,
                                FLCTL_INTFLAG_AVPRE_OFS))
                || (postRegVer
                        && BITBAND_PERI(FLCTL->rINTFLAG.r,
                                FLCTL_INTFLAG_AVPST_OFS)))
        {
            FlashCtl_disableWordProgramming();
            return false;
        } else
        {
            BITBAND_PERI(FLCTL->rINTCLR.r, FLCTL_INTCLR_PRG_OFS) = 1;
        }

        destAddr += 4;
        srcAddr += 4;
        length -= 4;

    }

    /* Do Burst Programming  (128-bit boundaries) */
    while (length > 63)
    {
        bCalc = 0;

        /* Setting/clearing INFO flash flags as appropriate */
        if (destAddr > __FLASH_END__)
        {
            FLCTL->rPRGBRST_CTLSTAT.r = (FLCTL->rPRGBRST_CTLSTAT.r
                    & ~FLCTL_PRGBRST_CTLSTAT_TYPE__M)
                    | FLCTL_PRGBRST_CTLSTAT_TYPE__1;
            otpOffset = __INFO_FLASH_START__;
        } else
        {
            FLCTL->rPRGBRST_CTLSTAT.r = (FLCTL->rPRGBRST_CTLSTAT.r
                    & ~FLCTL_PRGBRST_CTLSTAT_TYPE__M)
                    | FLCTL_PRGBRST_CTLSTAT_TYPE__0;
            otpOffset = __FLASH_START__;
        }

        /* Setup and do the burst program */
        FLCTL->rPRGBRST_STARTADDR.r = (destAddr - otpOffset);

        while (bCalc < 16 && length != 0)
        {
            HWREG32(__FLCTL_BASE__ + getBurstProgramRegs(bCalc)) = HWREG32(
                    srcAddr);
            srcAddr += 4;
            bCalc++;
            destAddr += 4;
            length -= 4;
        }

        /* Start the burst program */
        FLCTL->rPRGBRST_CTLSTAT.r = (FLCTL->rPRGBRST_CTLSTAT.r
                & ~(FLCTL_PRGBRST_CTLSTAT_LEN__M))
                | ((bCalc / 4) << FLASH_BURST_PRG_BIT)
                | FLCTL_PRGBRST_CTLSTAT_START;

        /* Waiting for the burst to complete */
        while ((FLCTL->rPRGBRST_CTLSTAT.r
                & FLCTL_PRGBRST_CTLSTAT_BURST_STATUS__M)
                != FLASH_PRGBRSTCTLSTAT_BURSTSTATUS_COMPLETE)
        {
            __no_operation();
        }

        /* Checking for errors and clearing/returning */
        if ((BITBAND_PERI(FLCTL->rPRGBRST_CTLSTAT.r, 21))
                || (preBrVer && BITBAND_PERI(FLCTL->rPRGBRST_CTLSTAT.r, 19))
                || (postBrVer && BITBAND_PERI(FLCTL->rPRGBRST_CTLSTAT.r, 20)))
        {
            FlashCtl_disableWordProgramming();
            return false;
        }

        BITBAND_PERI(FLCTL->rPRGBRST_CTLSTAT.r, FLCTL_PRGBRST_CTLSTAT_CLR_STAT_OFS) =
                1;
    }

    /* Doing full word accesses if we can */
    if (length > 15)
    {
        FlashCtl_enableWordProgramming(FLASH_COLLATED_WRITE_MODE);

        while (length > 15)
        {
            for (bCalc = 0; bCalc < 4; bCalc++)
            {
                HWREG32(destAddr) = HWREG32(srcAddr);
                destAddr += 4;
                srcAddr += 4;
            }

            while (!(FlashCtl_getInterruptStatus() & FLASH_WRDPRGM_COMPLETE))
            {
            }

            if ((FlashCtl_getInterruptStatus() & FLASH_PROGRAM_ERROR)
                    || (preRegVer
                            && BITBAND_PERI(FLCTL->rINTFLAG.r,
                                    FLCTL_INTFLAG_AVPRE_OFS))
                    || (postRegVer
                            && BITBAND_PERI(FLCTL->rINTFLAG.r,
                                    FLCTL_INTFLAG_AVPST_OFS)))
            {
                FlashCtl_disableWordProgramming();
                return false;
            } else
                BITBAND_PERI(FLCTL->rINTCLR.r, FLCTL_INTCLR_PRG_OFS) = 1;

            length -= 16;
        }

        FlashCtl_enableWordProgramming(FLASH_IMMEDIATE_WRITE_MODE);
    }

    /* Taking care of remaining words */
    while ((length > 3))
    {
        HWREG32(destAddr) = HWREG32(srcAddr);

        while (!(FlashCtl_getInterruptStatus() & FLASH_WRDPRGM_COMPLETE))
        {
        }

        if ((FlashCtl_getInterruptStatus() & FLASH_PROGRAM_ERROR)
                || (preRegVer
                        && BITBAND_PERI(FLCTL->rINTFLAG.r,
                                FLCTL_INTFLAG_AVPRE_OFS))
                || (postRegVer
                        && BITBAND_PERI(FLCTL->rINTFLAG.r,
                                FLCTL_INTFLAG_AVPST_OFS)))
        {
            FlashCtl_disableWordProgramming();
            return false;
        } else
            BITBAND_PERI(FLCTL->rINTCLR.r, FLCTL_INTCLR_PRG_OFS) = 1;

        destAddr += 4;
        srcAddr += 4;
        length -= 4;

    }

    /* Taking care of remaining bytes */
    while (length > 0)
    {
        HWREG8(destAddr++) = HWREG8(srcAddr++);
        length--;
        while (!(FlashCtl_getInterruptStatus() & FLASH_WRDPRGM_COMPLETE))
        {
        }

        if ((FlashCtl_getInterruptStatus() & FLASH_PROGRAM_ERROR)
                || (preRegVer
                        && BITBAND_PERI(FLCTL->rINTFLAG.r,
                                FLCTL_INTFLAG_AVPRE_OFS))
                || (postRegVer
                        && BITBAND_PERI(FLCTL->rINTFLAG.r,
                                FLCTL_INTFLAG_AVPST_OFS)))
        {
            FlashCtl_disableWordProgramming();
            return false;
        } else
            BITBAND_PERI(FLCTL->rINTCLR.r, FLCTL_INTCLR_PRG_OFS) = 1;
    }

    FlashCtl_disableWordProgramming();

    return true;
}

void FlashCtl_setProgramVerification(uint32_t verificationSetting)
{
    if ((verificationSetting & FLASH_BURSTPOST))
        BITBAND_PERI(FLCTL->rPRGBRST_CTLSTAT.r, FLCTL_PRGBRST_CTLSTAT_AUTO_PST_OFS) =
                1;

    if ((verificationSetting & FLASH_BURSTPRE))
        BITBAND_PERI(FLCTL->rPRGBRST_CTLSTAT.r, FLCTL_PRGBRST_CTLSTAT_AUTO_PRE_OFS) =
                1;

    if ((verificationSetting & FLASH_REGPRE))
        BITBAND_PERI(FLCTL->rPRG_CTLSTAT.r, FLCTL_PRG_CTLSTAT_VER_PRE_OFS) = 1;

    if ((verificationSetting & FLASH_REGPOST))
        BITBAND_PERI(FLCTL->rPRG_CTLSTAT.r, FLCTL_PRG_CTLSTAT_VER_PST_OFS) = 1;
}

void FlashCtl_clearProgramVerification(uint32_t verificationSetting)
{
    if ((verificationSetting & FLASH_BURSTPOST))
        BITBAND_PERI(FLCTL->rPRGBRST_CTLSTAT.r, FLCTL_PRGBRST_CTLSTAT_AUTO_PST_OFS) =
                0;

    if ((verificationSetting & FLASH_BURSTPRE))
        BITBAND_PERI(FLCTL->rPRGBRST_CTLSTAT.r, FLCTL_PRGBRST_CTLSTAT_AUTO_PRE_OFS) =
                0;

    if ((verificationSetting & FLASH_REGPRE))
        BITBAND_PERI(FLCTL->rPRG_CTLSTAT.r, FLCTL_PRG_CTLSTAT_VER_PRE_OFS) = 0;

    if ((verificationSetting & FLASH_REGPOST))
        BITBAND_PERI(FLCTL->rPRG_CTLSTAT.r, FLCTL_PRG_CTLSTAT_VER_PST_OFS) = 0;

}

void FlashCtl_enableWordProgramming(uint32_t mode)
{
    if (mode == FLASH_IMMEDIATE_WRITE_MODE)
    {
        BITBAND_PERI(FLCTL->rPRG_CTLSTAT.r, FLCTL_PRG_CTLSTAT_ENABLE_OFS) = 1;
        BITBAND_PERI(FLCTL->rPRG_CTLSTAT.r, FLCTL_PRG_CTLSTAT_MODE_OFS) = 0;

    } else if (mode == FLASH_COLLATED_WRITE_MODE)
    {
        BITBAND_PERI(FLCTL->rPRG_CTLSTAT.r, FLCTL_PRG_CTLSTAT_ENABLE_OFS) = 1;
        BITBAND_PERI(FLCTL->rPRG_CTLSTAT.r, FLCTL_PRG_CTLSTAT_MODE_OFS) = 1;
    }
}

void FlashCtl_disableWordProgramming(void)
{
    BITBAND_PERI(FLCTL->rPRG_CTLSTAT.r, FLCTL_PRG_CTLSTAT_ENABLE_OFS) = 0;
}

uint32_t FlashCtl_isWordProgrammingEnabled(void)
{
    if (!BITBAND_PERI(FLCTL->rPRG_CTLSTAT.r, FLCTL_PRG_CTLSTAT_ENABLE_OFS))
    {
        return 0;
    } else if (BITBAND_PERI(FLCTL->rPRG_CTLSTAT.r, FLCTL_PRG_CTLSTAT_MODE_OFS))
        return FLASH_COLLATED_WRITE_MODE;
    else
        return FLASH_IMMEDIATE_WRITE_MODE;
}

void FlashCtl_setWaitState(uint32_t flashBank, uint32_t waitState)
{
    if (flashBank == FLASH_BANK0)
    {
        FLCTL->rRDCTL_BNK0.r =
                (FLCTL->rRDCTL_BNK0.r & ~FLCTL_RDCTL_BNK0_WAIT__M)
                        | (waitState << 12);
    } else if (flashBank == FLASH_BANK1)
    {
        FLCTL->rRDCTL_BNK1.r =
                (FLCTL->rRDCTL_BNK1.r & ~FLCTL_RDCTL_BNK1_WAIT__M)
                        | (waitState << 12);
    } else
    {
        ASSERT(false);
    }
}

uint32_t FlashCtl_getWaitState(uint32_t flashBank)
{
    if (flashBank == FLASH_BANK0)
    {
        return FLCTL->rRDCTL_BNK0.b.bWAIT;
    } else if (flashBank == FLASH_BANK1)
    {
        return FLCTL->rRDCTL_BNK1.b.bWAIT;
    } else
    {
        ASSERT(false);
        return 0;
    }
}

void FlashCtl_enableInterrupt(uint32_t flags)
{
    FLCTL->rINTEN.r |= flags;
}

void FlashCtl_disableInterrupt(uint32_t flags)
{
    FLCTL->rINTEN.r &= ~flags;
}

uint32_t FlashCtl_getInterruptStatus(void)
{
    return FLCTL->rINTFLAG.r;
}

uint32_t FlashCtl_getEnabledInterruptStatus(void)
{
    return FlashCtl_getInterruptStatus() & FLCTL->rINTEN.r;
}

void FlashCtl_clearInterruptFlag(uint32_t flags)
{
    FLCTL->rINTCLR.r |= flags;
}

void FlashCtl_registerInterrupt(void (*intHandler)(void))
{
    //
    // Register the interrupt handler, returning an error if an error occurs.
    //
    Interrupt_registerInterrupt(INT_FLCTL, intHandler);

    //
    // Enable the system control interrupt.
    //
    Interrupt_enableInterrupt(INT_FLCTL);
}

void FlashCtl_unregisterInterrupt(void)
{
    //
    // Disable the interrupt.
    //
    Interrupt_disableInterrupt(INT_FLCTL);

    //
    // Unregister the interrupt handler.
    //
    Interrupt_unregisterInterrupt(INT_FLCTL);
}

